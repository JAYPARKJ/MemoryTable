INSERT INTO USER_TBL VALUES (
    USER_SEQ.NEXTVAL,
	:#{#oAuthVO.name}, :#{#oAuthVO.email},
    :#{#oAuthVO.mobile}, :#{#oAuthVO.role},
    sysdate, sysdate, :#{#oAuthVO.authVendor}
);