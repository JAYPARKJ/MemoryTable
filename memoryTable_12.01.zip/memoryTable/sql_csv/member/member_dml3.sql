-- 회원정보 삽입(생성)
INSERT INTO 
       MEMBER_TBL     
       (
 	     	ID
		  , PW
		  , NAME
		  , EMAIL
		  , MOBILE
		  , BIRTHDAY
		  , JOINDATE
	   )
       VALUES
       (
           'abcd1111',
           '#Abcd1234',
           '홍길동',
           'abcd1111@abcd.com',
           '010-1111-3333',
           '2000-01-01',
           SYSDATE
       )
;

-- 회원정보 존재 여부
SELECT COUNT(*) FROM MEMBER_TBL WHERE ID = 'abcd1111';

-- 회원정보 수정(갱신)
UPDATE
 	   MEMBER_TBL
   SET PW = '#Abcd1234'
 	 , MOBILE = '010-1234-5757'
 WHERE ID = 'abcd1111'
 ;
