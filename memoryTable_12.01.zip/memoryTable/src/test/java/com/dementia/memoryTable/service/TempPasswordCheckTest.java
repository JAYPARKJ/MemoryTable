package com.dementia.memoryTable.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class TempPasswordCheckTest {

	private static void generatePermutations(int[] arr, int start, List<List<Integer>> results) {
		if (start >= arr.length) {
			List<Integer> perm = new ArrayList<>();
			for (int num : arr) {
				perm.add(num);
			}
			results.add(perm);
			return;
		}

		for (int i = start; i < arr.length; i++) {
			swap(arr, start, i);
			generatePermutations(arr, start + 1, results);
			swap(arr, start, i); // backtrack
		}
	}

	private static void swap(int[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	private List<Integer> makeArr() {

		int[] numbers = { 1, 2, 3, 4 }; // 사용할 숫자
		List<List<Integer>> results = new ArrayList<>();
		generatePermutations(numbers, 0, results);

		List<Integer> returnVal = null;

		for (List<Integer> permutation : results) {
			int sum = permutation.stream().mapToInt(Integer::intValue).sum();
			if (sum >= 8 && sum <= 16) {
				returnVal = permutation;
			}
		}

		int idx = (int)(Math.random() * results.size());
		log.info("idx : " + idx);
		return results.get(idx);
	}

	@Test
	public void testMakeArr() {
		for (int i = 0; i < 10; i++) {
			System.out.println("makeArr : " + makeArr());
		}

	}

	@Test
	public void testNum() {
		// 4개의 수의 순열 합계가 8인 수의 순열
		int[] numbers = { 1, 2, 3, 4 }; // 사용할 숫자
		List<List<Integer>> results = new ArrayList<>();
		generatePermutations(numbers, 0, results);

		for (List<Integer> permutation : results) {
			int sum = permutation.stream().mapToInt(Integer::intValue).sum();
			if (sum >= 8 && sum <= 16) {
				System.out.println(permutation + " -> Sum: " + sum);
			}
		}
	}

	@Test
	public void testChar() {
		String arr[] = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S",
				"T", "U", "V", "W", "X", "Y", "Z" };
		List<Object> arrList = new ArrayList<>();
		arrList.addAll(Arrays.asList(arr));
		Collections.shuffle(arrList);

		arrList.forEach(x -> System.out.print(x + ", "));
	}

	@Test
	public void test() {

		for (int i = 0; i < 10; i++) {
			String pw = RandomMakeService.tempPassword();
			log.info("pw : " + pw);
			assertTrue(Pattern.matches("(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\\W).{8,20}", pw));
		}

	}
}
