package com.dementia.memoryTable.service;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.dementia.memoryTable.domain.DietVO;
import com.dementia.memoryTable.repository.DietDAO;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class GarbageImageCollectTest {

	@Autowired
	DietService dietService;

	@Value("${image.repo.location}")
	String imgPath;

	// DB, 파일 폴더에 동시에 존재하는 이미지 파일
	@Test
	void test() {

		log.info("imgPath : " + imgPath);
		// String imgName = "f58d6db55d9ff47e5b2127d0a06446261.jpg";
		String imgName = "c51e5b3d3dd65535608c536f2086910a1.jpg";
		imgPath = imgPath + imgName;
		log.info("imgPath : " + imgPath);
		assertTrue(Files.isReadable(Paths.get(imgPath)));
	}

	// DB에는 존재하고 파일 폴더에 존재하지 않는 이미지 파일
	@Test
	void test2() {

		log.info("imgPath : " + imgPath);
		// String imgName = "4ce52de1126a9aac398afe32c0e9191e1.jpg";
		// String imgName = "c51e5b3d3dd65535608c536f2086910a1.jpg";
		String imgName = "11a8b18b95cee4f343b35fe562ac03271.jpg";
		imgPath = imgPath + imgName;
		log.info("imgPath : " + imgPath);
		assertFalse(Files.isReadable(Paths.get(imgPath)));
	}

	// DB, 파일 폴더 이미지 일치하지 않는 레코드 삭제
	@Transactional
	@Test
	void test3() {

		List<DietVO> dietList = dietService.getAllDiets();

		// log.info("dietList.size : " + dietList.size());

		List<Integer> imgLostList = new ArrayList<>();

		// log.info("imgPath : " + imgPath);

		int cnt = 0;

		for (DietVO dietVO : dietList) {


			String imgName = dietVO.getFoodImg();
			String path = imgPath + imgName;
			// log.info("path : " + path);

			if (Files.isReadable(Paths.get(path)) == false) {
				cnt++;
				// log.info("lostImg : " + dietVO.getFoodImg());
				log.info("dietVO(lostImg) : " + dietVO);
				imgLostList.add(dietVO.getId());
			}
		} // for

		// log.info("cnt : " + cnt);

		// 일괄 삭제
		imgLostList.forEach(x -> {log.info("삭제 아이디 : " + x);});

		for (int id : imgLostList) {
			dietService.deleteById(id);
		}

	}

}
