package com.dementia.memoryTable.service;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import com.dementia.memoryTable.domain.MemberVO;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class MemberServiceTest1 {
	@Autowired
	MemberService memberService;
	
	MemberVO memberVO;
	
	@BeforeEach
	public void setUp() {
		memberVO = MemberVO.builder()
						   .id("abcdjava1")
						   .pw("#Abcd1234")
						   .name("자바맨")
						   .email("abcdJAVA1@abcd.com")
						   .mobile("010-1112-5454")
						   .birthday(Date.valueOf("1999-11-11"))
						   .build();
	}

	@Transactional
	@Rollback(true)
	@Test
	void testInsertMember() {
		assertTrue(memberService.insertMember(memberVO));
	}

}
