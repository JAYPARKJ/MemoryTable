package com.dementia.memoryTable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemoryTableApplicationTests {

	@Test
	void contextLoads() {
	}

}
