package com.dementia.memoryTable.service;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

import com.dementia.memoryTable.domain.MemberVO;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class MemberServiceTest2 {
	@Autowired
	// @Qualifier("") // 구현체가 여러개 있을 경우
	MemberService memberService;
	
	MemberVO memberVO;
	
	@BeforeEach
	public void setUp() {
		memberVO = MemberVO.builder()
						   .id("abcdjava1")
						   .pw("#Abcd1234")
						   .name("자바맨")
						   .email("abcdJAVA1@abcd.com")
						   .mobile("010-1112-5454")
						   .birthday(Date.valueOf("1999-11-11"))
						   // .joindate(new Date(System.currentTimeMillis()))
						   .joindate(Date.valueOf("2024-08-05"))
						   .build();
	}

//	@Test
//	void testInsertMember2() {
//		// assertThat(memberService.insertMember2(memberVO), equalTo(memberVO));
//		MemberVO actualVO = memberService.insertMember2(memberVO);
//		MemberVO expectedVO = memberVO;
//		assertTrue(expectedVO.equals(actualVO));
//	}

}
