package com.dementia.memoryTable.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.dementia.memoryTable.domain.naverAndGoogle.OAuthRole;
import com.dementia.memoryTable.domain.naverAndGoogle.OAuthVO;

import lombok.extern.slf4j.Slf4j;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Slf4j
class InsertOAuthUserTest {

	@Autowired
	UserRepository userRepository;
	
	OAuthVO oAuthVO;
	
	@BeforeEach
	public void beforeEach() {
		oAuthVO = OAuthVO.builder()
						.name("홍길동")
						.email("abcd1122@naver.com")
						.mobile("010-1111-2222")
						.authVendor("naver")
						.role(OAuthRole.USER)
						.build();
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	@Rollback(false)
	@Test
	void testInsertOAuthUser() {

		log.info("저장 전");

		OAuthVO result = userRepository.save(oAuthVO);
		log.info("result : {}", result);

		log.info("저장 후");
	}

}
