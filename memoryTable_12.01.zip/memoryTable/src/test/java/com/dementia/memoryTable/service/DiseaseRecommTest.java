package com.dementia.memoryTable.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.dementia.memoryTable.domain.DietVO;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class DiseaseRecommTest {

	@Autowired
	DietService dietService;

	@Test
	void testRecommList() {
		log.info("testRecommList");
		dietService.getRecomm("당뇨", 10).forEach(x -> {log.info("당뇨 추천 음식 : " + x);});
	}

	@Test
	void testRecommList2() {
		log.info("testRecommList");
		dietService.getRecomm("고지혈증", 10).forEach(x -> {log.info("고지혈증 추천 음식 : " + x);});
	}

	@Test
	void testRecommList3() {
		log.info("testRecommList");
		dietService.getRecomm("고혈압", 10).forEach(x -> {log.info("고혈압 추천 음식 : " + x);});
	}

	@Test
	void testRecommList4() {
		log.info("testRecommList");
		dietService.getRecomm("치매", 10).forEach(x -> {log.info("치매 추천 음식 : " + x);});
	}

	@Test
	void test() {
		// 10256 : 돼지불고기월남쌈 맛도 좋고 다이어트식으로도 그만이에요
		// String ing = "돼지고기 150g파프리카 1개간장 1.5숟갈다진마늘 1/3숟갈설탕 1/3~1/2숟갈부추 약간라이스페이퍼
		// 3~4장";
		// 10224 : 여름 보양식 쉬운 파개장 만들기
		String ing = "소고기 300g대파 10대느타리버섯 1팩국간장 1/2컵고춧가루 4큰술소금 1/2큰술마늘 2큰술진간장 1큰술국간장 3큰술참치 액젓 3큰술설탕 1작은술후추 톡톡고춧가루 1큰술들기름 1큰술식용유 3큰술설탕 1/2큰술간장 1/2큰술";

		// 고지혈증에 해로운 음식
		String filter = "곱창, 대창, 곱창 전골, 내장탕, 계란 노른자, 생선알, 생선내장(젓갈), 장어, 오징어, 새우, 굴, 소고기, 돼지고기, 닭껍질, 설렁탕, 곰탕, 갈비탕, 베이컨, 소시지, 햄, 버터, 크림, 치즈, 라면, 스낵, 커피 프림, 고지방 우유, 커피";

		String filters[] = filter.split(", ");
		log.info("filters.length : " + filters.length);

//		for (String s : filters) {
//			log.info(s);
//		}

		int cnt = 0; // 유해식품 포함 갯수
		for (String s : filters) {
			if (ing.contains(s) == true) {
				log.info("포함 유해식품 : " + s);
				cnt++;
			}
		}

		log.info("cnt : " + cnt);

	}

	// 고지혈증
	@Test
	void test2() {

		List<DietVO> diets = dietService.getAllDiets();
		log.info("diets : " + diets.size());

		// 고지혈증에 해로운 음식
		String filter = "곱창, 대창, 곱창 전골, 내장탕, 계란 노른자, 달걀, 계란, 노른자, 생선알, 명란, 생선내장(젓갈), 젓갈, 장어, 오징어, 새우, 굴, "
				+ "소고기, 쇠고기, 우육, 돼지고기, 돈육, 닭껍질, 설렁탕, 곰탕, 갈비탕, 베이컨, 삼겹살, 소시지, 소세지, 햄, 버터, 마가린, 크림, 치즈, 라면, 스낵, 커피 프림, 고지방 우유, 커피, 프림, 고지방, 내장";
		String filters[] = filter.split(", ");

		// 음식ID, 유해식품 포함 수
		Map<Integer, Integer> map = new HashMap<>();

		// 음식별 유해식품 갯수 점검
		for (DietVO dietVO : diets) {

			int cnt = 0; // 유해식품 포함 갯수

			if (dietVO.getIngredient() == null || dietVO.getIngredient().trim().equals("")) {

				continue;

			} else {

				for (String s : filters) {

					if (dietVO.getIngredient().contains(s) == true) {
						// log.info("포함 유해식품 : " + s);
						cnt++;
					}
				} // for

				map.put(dietVO.getId(), cnt);
			}

		} // for

//		log.info("식품별 유해식품 갯수 현황 : ");
//		map.entrySet().forEach(x -> {
//			log.info("" + x);
//		});

		Map<Integer, Integer> recommMap = new HashMap<>();

		// 유해식품이 없는게 최우선 -> 유해식품이 0이 아닌게 없다면 유해식품이 1인거에서 나열
		// 유해식품이 0인 레시피 검색
		for (int key : map.keySet()) {

			int value = map.get(key);

			if (value == 0) {
				recommMap.put(key, value);
			}
		}

		// 고지혈증 : 유해식품 없는 추천 식품
		log.info("고지혈증 유해식품 없는 추천 식품 현황 : " + recommMap.size());
		recommMap.entrySet().forEach(x -> {
			log.info("" + x);
		});

	}

	// 고혈압
	@Test
	void test3() {

		List<DietVO> diets = dietService.getAllDiets();
		log.info("diets : " + diets.size());

		// 고혈압에 해로운 음식
		String filter = "김치, 젓갈류, 젓갈, 장아찌, 게, 새우, 조개, 간장, 된장, 고추장, 쇠고기, 소고기, 우육, 돈육, 돼지고기, 비계, 내장, 곱창, 대창, 간, "
				+ "햄, 베이컨, 소세지, 소시지, 생선묵, 어묵, 오뎅, 커피, 홍차, 버터, 마가린, 쇼트닝, 치즈";
		String filters[] = filter.split(", ");

		// 음식ID, 유해식품 포함 수
		Map<Integer, Integer> map = new HashMap<>();

		// 음식별 유해식품 갯수 점검
		for (DietVO dietVO : diets) {

			int cnt = 0; // 유해식품 포함 갯수

			if (dietVO.getIngredient() == null || dietVO.getIngredient().trim().equals("")) {

				continue;

			} else {

				for (String s : filters) {

					if (dietVO.getIngredient().contains(s) == true) {
						// log.info("포함 유해식품 : " + s);
						cnt++;
					}
				} // for

				map.put(dietVO.getId(), cnt);
			}

		} // for

//		log.info("식품별 유해식품 갯수 현황 : ");
//		map.entrySet().forEach(x -> {
//			log.info("" + x);
//		});

		Map<Integer, Integer> recommMap = new HashMap<>();

		// 유해식품이 없는게 최우선 -> 유해식품이 0이 아닌게 없다면 유해식품이 1인거에서 나열
		// 유해식품이 0인 레시피 검색
		for (int key : map.keySet()) {

			int value = map.get(key);

			if (value == 0) {
				recommMap.put(key, value);
			}
		}

		// 고혈압 : 유해식품 없는 추천 식품
		log.info("고혈압 유해식품 없는 추천 식품 현황 : " + recommMap.size());
		recommMap.entrySet().forEach(x -> {
			log.info("" + x);
		});

	}

	// 당뇨
	@Test
	void test4() {

		List<DietVO> diets = dietService.getAllDiets();
		log.info("diets : " + diets.size());

		// 당뇨에 해로운 음식
		String filter = "베이컨, 햄등의 훈제 식품, 햄, 훈제, 소시지, 소세지, 설탕, 꿀 등의 단순당, 꿀, 허니, 사탕, 엿, 잼, 술, 단 쿠키, 쿠키, 파이류, 파이, 케이크, 케익, 초콜렛, 초콜릿, 양갱, "
				+ "젤리, 약과, 과일 통조림, 조청, 시럽, 꿀떡, 모과차, 유자차, 유색우유, 가당연유, 연유, 가당요구르트, 요구르트, 요거트, 설탕 입힌 플레이크, 플레이크, 후레이크";
		String filters[] = filter.split(", ");

		// 음식ID, 유해식품 포함 수
		Map<Integer, Integer> map = new HashMap<>();

		// 음식별 유해식품 갯수 점검
		for (DietVO dietVO : diets) {

			int cnt = 0; // 유해식품 포함 갯수

			if (dietVO.getIngredient() == null || dietVO.getIngredient().trim().equals("")) {

				continue;

			} else {

				for (String s : filters) {

					if (dietVO.getIngredient().contains(s) == true) {
						// log.info("포함 유해식품 : " + s);
						cnt++;
					}
				} // for

				map.put(dietVO.getId(), cnt);
			}

		} // for

//			log.info("식품별 유해식품 갯수 현황 : ");
//			map.entrySet().forEach(x -> {
//				log.info("" + x);
//			});

		Map<Integer, Integer> recommMap = new HashMap<>();

		// 유해식품이 없는게 최우선 -> 유해식품이 0이 아닌게 없다면 유해식품이 1인거에서 나열
		// 유해식품이 0인 레시피 검색
		for (int key : map.keySet()) {

			int value = map.get(key);

			if (value == 0) {
				recommMap.put(key, value);
			}
		}

		// 당뇨 : 유해식품 없는 추천 식품
		log.info("당뇨 유해식품 없는 추천 식품 현황 : " + recommMap.size());
		recommMap.entrySet().forEach(x -> {
			log.info("" + x);
		});

	}

	// 치매
	@Test
	void test5() {

		List<DietVO> diets = dietService.getAllDiets();
		log.info("diets : " + diets.size());

		// 치매에 해로운 음식
		String filter = "버터, 치즈, 마가린, 마요네즈, 삼겹살, 햄버거, 치킨, 과자, 술, 쿠키, 설탕, 밀가루, 케이크, 케익";
		String filters[] = filter.split(", ");

		// 음식ID, 유해식품 포함 수
		Map<Integer, Integer> map = new HashMap<>();

		// 음식별 유해식품 갯수 점검
		for (DietVO dietVO : diets) {

			int cnt = 0; // 유해식품 포함 갯수

			if (dietVO.getIngredient() == null || dietVO.getIngredient().trim().equals("")) {

				continue;

			} else {

				for (String s : filters) {

					if (dietVO.getIngredient().contains(s) == true) {
						// log.info("포함 유해식품 : " + s);
						cnt++;
					}
				} // for

				map.put(dietVO.getId(), cnt);
			}

		} // for

//				log.info("식품별 유해식품 갯수 현황 : ");
//				map.entrySet().forEach(x -> {
//					log.info("" + x);
//				});

		Map<Integer, Integer> recommMap = new HashMap<>();

		// 유해식품이 없는게 최우선 -> 유해식품이 0이 아닌게 없다면 유해식품이 1인거에서 나열
		// 유해식품이 0인 레시피 검색
		for (int key : map.keySet()) {

			int value = map.get(key);

			if (value == 0) {
				recommMap.put(key, value);
			}
		}

		// 치매 : 유해식품 없는 추천 식품
		log.info("치매 유해식품 없는 추천 식품 현황 : " + recommMap.size());
		recommMap.entrySet().forEach(x -> {
			log.info("" + x);
		});

	}

}
