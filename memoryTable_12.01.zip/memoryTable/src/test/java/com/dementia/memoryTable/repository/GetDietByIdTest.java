package com.dementia.memoryTable.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.dementia.memoryTable.domain.DietVO;
import com.dementia.memoryTable.domain.Ingredient;
import com.dementia.memoryTable.service.DietService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class GetDietByIdTest {

	@Autowired
	DietService dietService;

	@Test
	void testGetDietById() {
		DietVO dietVO = dietService.getDietById(10253);
		log.info("dietVO : " + dietVO.getIngredient());

		String formattedIngredients = Ingredient.formatIngredients(dietVO.getIngredient());
		log.info("formattedIngredients : " + formattedIngredients);
	}

}
