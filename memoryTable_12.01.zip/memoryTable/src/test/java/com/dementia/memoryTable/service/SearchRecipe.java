package com.dementia.memoryTable.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class SearchRecipe {

	@Autowired
	RecipeService recipeService;

	// case-1) 검색 시 현재의 레시피 데이터에서 특정 검색 구분에 대한 레코드 수를 점검
	// case-1-1) 검색 구분(레시피) 검색어(칼국수)로 검색시 기댓값(ex.5) 인지 점검
	@Test
	void testSelectRecipeBySearchingAndPaging() {
	}

}
