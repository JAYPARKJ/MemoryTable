package com.dementia.memoryTable.repository;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class RecipePagingTest {

	@Autowired
	RecipeDAO recipeDAO;

	String searchKey;
	String searchWord;
	int page;
	int limit;
	String ordering;

	List<Map<String, Object>> recipes;

	// case-1) 레시피 검색 : "칼국수" 라는 검색어로 레시피 검색
	// case-1-1) Null 여부 점검
	// case-1-2) 페이지당 레코드 길이 => 첫 페이지, 마지막 페이지
	// case-1-3) 정렬시(오름차순) => 처음/마지막 레코드 이름 비교
	// case-1-4) 정렬시(내림차순) => 처음/마지막 레코드 이름 비교
	@Test
	void testSelectRecipeBySearchingAndPaging() {
		searchKey = "FOOD_NAME";
		searchWord = "칼국수";
		page = 1;
		limit = 10;
		ordering = "ASC";

		recipes = recipeDAO.selectRecipeBySearchingAndPaging(searchKey, searchWord, page, limit, ordering);

		// case-1-1) Null 여부 점검
		assertNotNull(recipes);

		// case-1-2) 페이지당 레코드 길이
		assertEquals(5, recipes.size());
	}

	// case-1-3) 정렬시(오름차순) => 처음/마지막 레코드 이름 비교
	@Test
	void testSelectRecipeBySearchingAndPagingAsc() {
		searchKey = "FOOD_NAME";
		searchWord = "칼국수";
		page = 1;
		limit = 10;
		ordering = "ASC";

		recipes = recipeDAO.selectRecipeBySearchingAndPaging(searchKey, searchWord, page, limit, ordering);

		// 1페이지의 처음/마지막 레코드 레시피 : 가을 보양식 팥칼국수 만드는법 / 들깨칼국수
		assertThat("가을 보양식 팥칼국수 만드는법", equalTo(recipes.get(0).get("FOOD_NAME")));
		assertThat("들깨칼국수", equalTo(recipes.get(4).get("FOOD_NAME")));
	}

	// case-1-4) 정렬시(내림차순) => 처음/마지막 레코드 이름 비교
	@Test
	void testSelectRecipeBySearchingAndPagingDesc() {
		searchKey = "FOOD_NAME";
		searchWord = "칼국수";
		page = 1;
		limit = 10;
		ordering = "ASC";

		recipes = recipeDAO.selectRecipeBySearchingAndPaging(searchKey, searchWord, page, limit, ordering);

		// 1페이지의 처음/마지막 레코드 레시피 : 들깨칼국수/ 가을 보양식 팥칼국수 만드는법
		assertThat("들깨칼국수", equalTo(recipes.get(4).get("FOOD_NAME")));
		assertThat("가을 보양식 팥칼국수 만드는법", equalTo(recipes.get(0).get("FOOD_NAME")));
	}

}
