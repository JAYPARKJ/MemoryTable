/**
 *
 */

function isCheckFldValid(fld, regex, initVal, errPnl, errMsg) {

	// 리턴값 : 에러 점검 플래그
	let fldCheckFlag = false;

	// 체크 대상 필드 값 확인
	console.log(`체크 대상 필드 값 : ${fld.value}`);

	// 폼 유효성 점검(test)
	console.log(`점검 여부 : ${regex.test(fld.value)}`);

	if (regex.test(fld.value) == false) {

		// errPnl.style.height = "20px";
		// errPnl.innerHTML = errMsg;

		// 기존 필드 데이터 초기화
		// fld.value = "";
		fld.value = initVal;
		fld.focus(); // 재입력 준비

		fldCheckFlag = false;

	} else { // 정상

		// 에러 패널 초기화
		// errPnl.style.height = "0";
		// errPnl.innerHTML = "";

		fldCheckFlag = true;
	} // if

	return fldCheckFlag;
} //

////////////////////////////////////////////////////////////////////////

// 경과시간 표시 포맷 함수
function formatTime(time) {
	let minutes = parseInt(time / 60);
	let seconds = time - 60 * minutes;

	minutes = minutes < 10 ? "0" + minutes : minutes;
	seconds = seconds < 10 ? "0" + seconds : seconds;

	return minutes + ":" + seconds;
}

////////////////////////////////////////////////////////////////////////

window.onload = function() {

	// 각 필드들의 에러 점검 여부 (플래그(flag) 변수)
	let idCheckFlag = false;

	// 아이디 중복 점검 플래그
	let idDuplicatedCheckFlag = false;

	// 이메일 점검 플래그
	let emailCheckFlag = false;

	// 아이디 필드 폼 점검(form validation)
	// 아이디 필드 인식
	let idFld = document.getElementById("id");

	// 아이디 에러 패널 인식
	let idFldErrPnl = document.getElementById("id_fld_err_pnl");

	// 이메일 필드 인식
	let emailFld = document.getElementById("email");

	// 이메일 필드 에러 패널 인식
	let emailFldErrPnl = document.getElementById("email_fld_err_pnl");

	////////////////////////////////////////////////////////////////////////

	// 에러 메시지
	let idErrMsg = "5~20자/영문 대소문자,숫자 사용가능";

	let emailErrMsg = "이메일을 다시 입력해주세요";

	////////////////////////////////////////////////////////////////////////

	// 아이디 필드 유효성 및 중복 점검
	idFld.onblur = () => {

		console.log(`아이디 중복 점검 : ${idFld.value}`);

		idCheckFlag = isCheckFldValid(idFld,
			/^[a-zA-Z]{1}\w{7,19}$/,
			idFld.value,
			idFldErrPnl,
			idErrMsg);

		if (idCheckFlag == true) {

			console.log("아이디 유효성 점검 성공");

			axios.get(`/memoryTable/member/hasFld/ID/${idFld.value}`)
				 .then(function(response) {

					// console.log("서버 응답 : " + JSON.stringify(response));

					idDuplicatedCheckFlag = response.data;

					console.log("response.data : ", response.data);
					// console.log("response.data : ", typeof(response.data));

					let idDupErrMsg = idDuplicatedCheckFlag == true ? "중복되는 아이디가 존재합니다" : "존재하지 않는 아이디입니다."
					console.log(idDupErrMsg);

					// 메시지 반복 출력 방지 : 출력할 메시지 있으면 출력
					if (idDuplicatedCheckFlag == false) {

						Swal.fire({
							icon: "warning",
							title: idDupErrMsg,
							text: "다시 한번 확인해주세요.",
						});

						idFld.value = "";
					}

				 })
				.catch(function(err) {
					console.error("아이디 중복 점검 중 서버 에러가 발견되었습니다");
					//idDuplicatedCheckFlag = false;
				});

		} // if

	} // idFld.onkeyup ...

	////////////////////////////////////////////////////////////////////

	// 이메일 필드 유효성 및 중복 점검
	emailFld.onkeyup = () => {

		console.log("이메일 필드 onkeyup")
		// 이메일 필드 유효성 점검(validation)
		// 기준)
		/*
			1) "@", "." 포함여부 점검
			2) regex(정규표현식) : /^[a-zA-Z0-9_+.-]+@([a-zA-Z0-9-]+\.)+[a-zA-Z0-9]{2,4}$/
			3) 메시징 : 회원 이메일을 작성하십시오
		*/
		emailCheckFlag = isCheckFldValid(emailFld,
			/^[a-zA-Z0-9_+.-]+@([a-zA-Z0-9-]+\.)+[a-zA-Z0-9]{2,4}$/,
			emailFld.value,
			emailFldErrPnl,
			emailErrMsg);

		if (emailCheckFlag == false) {

		}
	} //

	////////////////////////////////////////////////////////////////////

	let sendNum = document.getElementById("sendNum"); // 임시비밀번호 발급 버튼 필드

	sendNum.onclick = function(e) {
		console.log("인증번호 발급 클릭");

		emailCheckFlag = isCheckFldValid(emailFld,
			/^[a-zA-Z0-9_+.-]+@([a-zA-Z0-9-]+\.)+[a-zA-Z0-9]{2,4}$/,
			emailFld.value,
			emailFldErrPnl,
			emailErrMsg);

		// 버그 패치 : 09.26
		// 이메일 유효성 점검 성공

		console.log("이메일 유효성 점검 성공");

		console.log("email : " + emailFld.value);

		axios.get(`/memoryTable/sendPw/${idFld.value}/${emailFld.value}`)
			.then(function(response) {

				console.log("response : ", response);

				// 발급 번호
				console.log("response.data : ", response.data);

				// alert 커스텀
				Swal.fire({
					icon: "success",
					title: "임시 비밀번호가 발급 되었습니다.",
					text: "이메일을 확인해주세요.",
				});

			})
			.catch(function(err) {
				console.error("서버 에러가 발견되었습니다 : ", err);
			}); // axios

	} // onclick

	////////////////////////////////////////////////////////////////////
}