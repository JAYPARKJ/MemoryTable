/**
 *
 */

window.onload = function() {

	// 검색 버튼 전송시 폼점검 : 검색어 공백 점검
	let searchBtn = document.getElementById("search_btn");
	let searchWord = document.getElementById("searchWord");

	searchBtn.onclick = (e) => {

		if (searchWord.value.trim() == '') {

			searchWord.focus();
		}

	} //
}