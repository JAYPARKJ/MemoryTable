/**
 *
 */
window.onload = function() {

	// 회원 정보 삭제 버튼 (자체 로그인)
	let deleteBtns = document.querySelectorAll("[id^=delete_btn]");

	for (deleteBtn of deleteBtns) {
		deleteBtn.onclick = (e) => {
			id = e.target.id;
			id = id.substring('delete_btn'.length);

			console.log("id : " + id);

			if (confirm(`${id}님 정말 탈퇴하시겠습니까?`) == true) {
				Swal.fire({
					icon: "success",
					title: "",
					text: "회원 삭제 되었습니다.",
				}).then(function() {
					location.href='/memoryTable/logout';
				});

				axios.get(`/memoryTable/member/deleteMember/${id}`)
					.then(function(response) {
						console.log("response.data : ", response.data);

						// 화면 이동 : logout
						// location.href = "/memoryTable/logout";
					})
					.catch(function(err) {
						console.error("회원 정보 삭제 중 서버 에러가 발견되었습니다.");
						// alert(`{id} 님의 회원 정보 삭제 중 서버 에러가 발견되었습니다.`);
						Swal.fire({
							icon: "error",
							title: "",
							text: "회원 정보 삭제 중 오류가 발생했습니다.",
						});
					}); // axios
			} else {
				Swal.fire({
					icon: "warning",
					title: "",
					text: "회원 탈퇴를 취소했습니다.",
				});
			} // if-else

		} // deleteBtn.onclick

	} // for

	///////////////////////////////////////////////////////////////////////////////

	// 회원 정보 삭제 버튼 (naver & google 로그인)
	let deleteNaverGoogleBtns = document.querySelectorAll("[id^=delete_naver_google_btn_]");

	for (deleteBtn of deleteNaverGoogleBtns) {
		deleteBtn.onclick = (e) => {
			emailAuthVendor = e.target.id;
			emailAuthVendor = emailAuthVendor.substring('delete_naver_google_btn_'.length);
			let temp = emailAuthVendor.split('-');
			let email = temp[0];
			let authVendor = temp[1];

			console.log("email : " + email);
			console.log("authVendor : " + authVendor);

			if (confirm(`정말 탈퇴하시겠습니까?`) == true) {

				Swal.fire({
					icon: "success",
					title: "",
					text: "회원 삭제 되었습니다.",
				}).then(function() {
					location.href='/memoryTable/logout';
				});

				axios.get(`/memoryTable/member/deleteMemberByAuth/${email}/${authVendor}`)
					.then(function(response) {
						console.log("response.data : ", response.data);

						// 화면 이동 : logout
						// location.href = "/memoryTable/logout";
					})
					.catch(function(err) {
						console.error("회원 정보 삭제 중 서버 에러가 발견되었습니다.");

						Swal.fire({
							icon: "error",
							title: "",
							text: "회원 정보 삭제 중 오류가 발생했습니다.",
						});
					}); // axios
			} else {
				Swal.fire({
					icon: "warning",
					title: "",
					text: "회원 탈퇴를 취소했습니다.",
				});
			} // if-else

		} // deleteBtn.onclick

	} // for

}