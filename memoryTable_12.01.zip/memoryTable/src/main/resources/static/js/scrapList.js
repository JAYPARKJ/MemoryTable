/**
 *
 */

function deleteScrap(foodId, username) {

	let scrapDeleteBtn = document.getElementById(`scrap_delete_btn_${foodId}`);

	if (scrapDeleteBtn != null) {

		scrapDeleteBtn.onclick = function() {
			console.log("삭제할 레시피 아이디 : ", foodId);

			if (confirm("스크랩한 레시피를 삭제하겠습니까?") == true) {
				let str = `/memoryTable/scrap/deleteProc?foodId=${foodId}`;

				console.log('str : ' + str);

				location.href = str;
			} else {
				alert("삭제할 수 없습니다.");
			}
		}
	} else {
		console.log("삭제 권한이 없습니다.");
	}
}