document.getElementById("favoriteIcon").addEventListener("click", function() {
    let icon = document.getElementById("favoriteIcon");
    
    // 현재 아이콘의 src를 확인하여 변경
    if (icon.src.includes("img/star-empty1.png")) {
        icon.src = "img/star-filled1.png";  // 클릭 시 꽉 찬 아이콘으로 변경
    } else {
        icon.src = "img/star-empty1.png";   // 다시 클릭 시 빈 아이콘으로 변경
    }
});