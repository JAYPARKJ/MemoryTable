/*  window.onload = function() { */
document.addEventListener("DOMContentLoaded", function() {

	console.log("생일 계산 JS");
	// CORS 설정
	axios.defaults.withCredentials = true;

	// 생년월일 입력 시 나이 계산
	const birthdayInput = document.getElementById('birthday');
	const additionalInfoInput = document.getElementById('additional_info');
	const calculateAgeButton = document.getElementById('calculateAgeButton'); // 나이 계산 버튼

	// 11.01
	// 초기화 : 날짜 한계(max) 금일 초기화
	// ex) 2024-08-23 formatting
	// 달력 컨퍼넌트에서의 날짜 제한
	birthdayInput.max = new Date().toISOString().substring(0, 10);

	/* birthdayInput.addEventListener('change', function() {
		const birthdayValue = this.value; */

	calculateAgeButton.onclick = function() {
		console.log("생일계산");
		const birthdayValue = birthdayInput.value;

		if (!birthdayValue) {
			additionalInfoInput.value = "";
			console.log("빈 값이 입력됨");
			return;
		}

		const birthday = new Date(birthdayValue);
		const today = new Date();

		if (isNaN(birthday.getTime()) || birthday > today) {
			alert("유효한 생일을 입력하세요.");
			additionalInfoInput.value = '';
			return;
		}

		let age = today.getFullYear() - birthday.getFullYear();
		const monthDiff = today.getMonth() - birthday.getMonth();
		if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthday.getDate())) {
			age--;
		}

		additionalInfoInput.value = age;
		console.log("계산된 나이:", age);
	};


});