/**
 *
 */

function isCheckFldValid(fld, regex, initVal, errPnl, errMsg) {

    // 리턴값 : 에러 점검 플래그
    let fldCheckFlag = false;

    // 체크 대상 필드 값 확인
    console.log(`체크 대상 필드 값 : ${fld.value}`);

    // 폼 유효성 점검(test)
    console.log(`점검 여부 : ${regex.test(fld.value)}`);

    if (regex.test(fld.value) == false) {

        errPnl.style.height = "20px";
        errPnl.innerHTML = errMsg;

        // 기존 필드 데이터 초기화
        // fld.value = "";
        fld.value = initVal;
        fld.focus(); // 재입력 준비

        fldCheckFlag = false;

    } else { // 정상

        // 에러 패널 초기화
        errPnl.style.height = "0";
        errPnl.innerHTML = "";

        fldCheckFlag = true;
    } // if

    return fldCheckFlag;
} //

////////////////////////////////////////////////////////////////////////

window.onload = function() {

	// 이메일 점검 플래그
	let emailCheckFlag = false;

	// 이메일 중복 점검 플래그
	let emailDuplicatedCheckFlag = false;

	 // 이름 필드 인식
    let nameFld = document.getElementById("name");

    // 이름 에러 패널 인식
    let nameFldErrPnl = document.getElementById("name_fld_err_pnl");

	// 이메일 필드 인식
	let emailFld = document.getElementById("email");

	// 이메일 필드 에러 패널 인식
	let emailFldErrPnl = document.getElementById("email_fld_err_pnl");

	////////////////////////////////////////////////////////////////////////

	// 에러 메시지

	let nameErrMsg = "이름을 입력해주세요";

	let emailErrMsg = "이메일을 다시 입력해주세요";

	////////////////////////////////////////////////////////////////////////

	// 이름 필드 입력 후 이벤트 처리 : blur
    nameFld.onblur = (e) => {

        console.log("이름 필드 blur")
        // 이름 필드 유효성 점검(validation)
        // 기준)
        /*
            1) 한글"만" : 3~50자 (성함 사이 띄워쓰기 포함)
            2) 성/함(이름) : ex) 홍길동, 남궁민수
            3) regex(정규표현식) : /^[가-힣]{1,2}[가-힣]{1,48}$/
            4) 메시징 : 회원 이름은 한글 이름만 허용됩니다.
        */
        nameCheckFlag = isCheckFldValid(nameFld,
                        /^[가-힣]{1,2}[가-힣]{1,48}$/,
                        "",
                        nameFldErrPnl,
                        nameErrMsg);
    } //

    // 이름 필드 입력 후 이벤트 처리 : keyup
    nameFld.onkeyup = (e) => {

        console.log("이름 필드 blur")
        nameCheckFlag = isCheckFldValid(nameFld,
                        /^[가-힣]{1,2}[가-힣]{1,48}$/,
                        nameFld.value,
                        nameFldErrPnl,
                        nameErrMsg);
    } //

    ////////////////////////////////////////////////////////////////////////

	// 이메일 필드 유효성 및 중복 점검
    emailFld.onkeyup = (e) => {

        console.log("이메일 필드 onkeyup")
        // 이메일 필드 유효성 점검(validation)
        // 기준)
        /*
            1) "@", "." 포함여부 점검
            2) regex(정규표현식) : /^[a-zA-Z0-9_+.-]+@([a-zA-Z0-9-]+\.)+[a-zA-Z0-9]{2,4}$/
            3) 메시징 : 회원 이메일을 작성하십시오
        */
		emailCheckFlag = isCheckFldValid(emailFld,
                        /^[a-zA-Z0-9_+.-]+@([a-zA-Z0-9-]+\.)+[a-zA-Z0-9]{2,4}$/,
                        emailFld.value,
                        emailFldErrPnl,
                        emailErrMsg);

		if (emailCheckFlag == true) {

			console.log("이메일 유효성 점검 성공");

			axios.get(`/memoryTable/member/hasFld/EMAIL/${emailFld.value}`)
				 .then(function(response) {

					emailDuplicatedCheckFlag = response.data;
					console.log("response.data : ", response.data);

					let emailDupErrMsg = emailDuplicatedCheckFlag == true ? "중복되는 이메일이 존재합니다" : "사용가능한 이메일입니다"
					console.log(emailDupErrMsg)

					// 메시지 반복 출력 방지 : 출력할 메시지 있으면 출력
					if (emailDuplicatedCheckFlag == true) {

						alert(emailDupErrMsg);
						emailFld.value = "";
					}

				 })
				 .catch(function(err) {
					console.error("이메일 중복 점검 중 서버 에러가 발견되었습니다");
					//emailDuplicatedCheckFlag = false;
				 });
		} // if
    } //

	////////////////////////////////////////////////////////////////////
}