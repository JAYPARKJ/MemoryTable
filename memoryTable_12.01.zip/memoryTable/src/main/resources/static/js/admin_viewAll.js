/**
 *
 */

/////////////////////////////////////////////////////////////////////////////////////////////
//
//
// 에러 메시징 함수
// 기능 : 필드별로 폼 점검 시행 후 에러 메시징(패널)
//        개별 필드 체크 플래그에 리턴
// 1) 함수명 : isCheckFldValid
// 2) 인자 :
// 필드 (아이디) 변수(fld), 필드 기정값(initVal),
// 필드별 정규표현식(유효성 점검 기준) (regex)
// 필드별 에러 메시지(errMsg)
// 3) 리턴 : fldCheckFlag : boolean (true/false) : 유효/무효
// 4) 용례(usage) :
// idCheckFlag = isCheckFldValid(idFld,
//                        /^[a-zA-Z]{1}\w{7,19}$/,
//                        "",
//                        "회원 아이디는 8~20사이의 영문으로
//                        시작하여 영문 대소문자/숫자로 입력하십시오.")
function isCheckFldValid(fld, regex, initVal, errMsg) {

    // 리턴값 : 에러 점검 플래그
    let fldCheckFlag = false;

    // 체크 대상 필드 값 확인
    console.log(`체크 대상 필드 값 : ${fld.value}`);

    // 폼 유효성 점검(test)
    console.log(`점검 여부 : ${regex.test(fld.value)}`);

    if (regex.test(fld.value) == false) {

        alert(errMsg); // 팝업 출력
        fldCheckFlag = false;
    } else {
	   fldCheckFlag = true;
	}

    return fldCheckFlag;
} //

////////////////////////////////////////////////////

window.onload = function() {

	//
	// 검색 버튼 전송시 폼점검 : 검색어 공백 점검
	let searchBtn = document.getElementById("search_btn");
	let searchWord = document.getElementById("searchWord");

	searchBtn.onclick = (e) => {

		if (searchWord.value.trim() == '') {

			searchWord.focus();
		}

	} //

	///////////////////////////////////////////////////////////////////////////////
	//
	// 활동 여부 설정 : 회원 활동/휴면 계정 설정
	let enabledUpdateBtns = document.querySelectorAll("[id^=enabled_update_btn_]");

	for (enabledUpdateBtn of enabledUpdateBtns) {

		enabledUpdateBtn.onclick = (e) => {

			let msg = "";

			let id = e.target.id; // 'enabled_'~~~
			id = id.substring('enabled_update_btn_'.length);

			let enabled = document.getElementById('enabled_'+id).value;

			console.log("회원 활동 변경 : ",  id, ', ', enabled);

			axios.get(`/memoryTable/admin/changeMemberState/${id}/${enabled}`)
				 .then(function(response) {

						console.log("response.data === true : ", response.data === true);

						if (response.data === true) {
							msg = "회원 활동 상태 변경 처리에 성공하였습니다.";
						}

						Swal.fire({
							icon: "success",
							title: "",
							text: "회원 활동 상태가 변경되었습니다.",
						});

					 })
					 .catch(function(err) {
						console.error("회원 활동 상태 변경 처리에 실패하였습니다. : ", err.error);
						Swal.fire({
							icon: "error",
							title: "",
							text: "회원 활동 상태 변경에 실패했습니다.",
						});
					 });
				// axios

		} // onclick

	} // for

	///////////////////////////////////////////////////////////////////////////////////
	//
	// 회원 정보 (일괄) 수정 버튼
	//
	let updateBtns = document.querySelectorAll("[id^=update_btn]");

	for (updateBtn of updateBtns) {

		updateBtn.onclick = (e) => {

			let id = e.target.id; // 'mobile_' ~~~
			id = id.substring('update_btn'.length);

			let updateBtn = document.getElementById('update_btn'+id);

		} //

	} // for

	///////////////////////////////////////////////////////////////////////////////////
	//
	// (개별) 회원 정보 (일괄) 삭제 버튼
	//
	let deleteBtns = document.querySelectorAll("[id^=delete_btn]");

	for (deleteBtn of deleteBtns) {

		deleteBtn.onclick = (e) => {

			id = e.target.id;
			id = id.substring('delete_btn'.length);

			// let deleteBtn = document.getElementById('delete_btn'+id);

			if (confirm(`${id} 님의 회원 정보를 정말 삭제하시겠습니까?`) == true) {

				Swal.fire({
					icon: "success",
					title: "",
					text: "회원 삭제 되었습니다.",
				}).then(function() {
					location.href='./viewAllWithRoles';
				});

				axios.get(`/memoryTable/admin/deleteMemberByAdmin/${id}`)
				 .then(function(response) {

					console.log("response.data : ", response.data);

				 })
				 .catch(function(err) {
					console.error("개별 회원 정보 삭제 중 서버 에러가 발견되었습니다.");
					// alert(`${id} 님의 회원 정보 삭제 중 서버 에러가 발견되었습니다.`);
					Swal.fire({
						icon: "warning",
						title: "",
						text: "회원 삭제 중 오류가 발생했습니다.",
					});
				 });
				// axios

			} else {
				Swal.fire({
					icon: "warning",
					title: "",
					text: "회원 삭제를 취소했습니다.",
				});
			} //

		} // onclick

	} // for

	///////////////////////////////////////////////////////////////////////////////////

	// 추가) "검색 구분" 필드가 변경될 때마다 입력 예시 문구(안내문) 및 필드 변경
	let searchKey = document.getElementById("searchKey");
	// let searchWord = document.getElementById("searchWord");
	let guideText = ""

	searchKey.onchange = function() {

		switch (searchKey.value) {

			case "id" : guideText = "8~20자로 영문/숫자로 작성합니다"; break;
			case "name" : guideText = "한글로 입력합니다"; break;
			case "email" : guideText = "abcd@abcd.com과 같이 입력합니다"; break;
			case "mobile" : guideText = "010-1234-5678와 같이 입력합니다"; break;
			case "birthday" : guideText = "2000-01-01과 같이 입력합니다"; break;
			case "joindate" : guideText = "2000-01-01과 같이 입력합니다"; break;
			case "role" : guideText = "'관리자' 혹은 '회원'으로 입력합니다"; break;
		}

		searchWord.placeholder = guideText;

		// 가입일, 생일일 경우는 년월일 입력하도록 date 필드로 변환 조치
		// 다른 필드일 경우는 text 필드로 재변환
		if (searchKey.value == "birthday" || searchKey.value == "joindate") {
			searchWord.type="date";
		} else {
			searchWord.type="text";
		} //
	}

} // onload
