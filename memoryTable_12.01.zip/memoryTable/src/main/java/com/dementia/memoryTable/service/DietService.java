package com.dementia.memoryTable.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dementia.memoryTable.domain.DietVO;
import com.dementia.memoryTable.domain.DiseaseVO;
import com.dementia.memoryTable.repository.DietDAO;
import com.dementia.memoryTable.repository.DiseaseDAO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DietService {

	@Autowired
	DietDAO dietDAO;

	@Autowired
	DiseaseDAO diseaseDAO;

	// 11.12
	public List<DietVO> getDietsByIds(List<Integer> ids) {
		List<DietVO> list = new ArrayList<>();

		for (int id : ids) {
			list.add(dietDAO.findById(id).get());
		}

		return list;
	}

	// 11.12 ID로 조회
	public List<DietVO> getAllDiets() {
		return (List<DietVO>) dietDAO.findAll();
	}

	public List<DietVO> getDietList(int page, int limit){

		// 페이징으로 불러오기 (jpa)
		Pageable pageable = PageRequest.of(page-1, limit);
		return dietDAO.findAll(pageable).getContent();

	}

	public int getAllCount() {

		return (int)dietDAO.count();
	}


	public DietVO getDietById(Integer id) {
		   return dietDAO.findById(id)
		            .orElseThrow(() -> new IllegalArgumentException("해당 ID의 레시피가 존재하지 않습니다."));
	}

	// 10.20일 추가
    // 인기 레시피 상위 4개 가져오기
    public List<DietVO> getTop4PopularDiets() {
        return dietDAO.findTop4ByOrderByIdAsc(PageRequest.of(0, 4));
    }

    // 최신 레시피 상위 8개 가져오기
    public List<DietVO> getTop8NewsDiets() {
        return dietDAO.findTop8ByOrderByIdDesc(PageRequest.of(0, 8));
    }

    public List<DietVO> searchByQuery(String query) {

    	 // 검색 로직 구현
        return dietDAO.findByFoodNameContainingOrIngredientContaining(query, query);
    }

    /**
     * 유해식품 필터링
     * @param harm 질병별 유해식품군
     * @param targetIngres 음식별 재료들 (출처 : DietVO)
     * @return harmfulFoodRatio 유해식품 함유량
     */
    public float checkHarmfulFood(String harm, String targetIngres) {

    	// , 구분자(delimeter) split
		String[] harms = harm.split("\\, ");
		log.info("harms : " + harms.length);
		List<Object> harmList = Arrays.asList(harms);
		log.info("harmlistSize: " + harmList.size());

		log.info("targetIngres: ");
		// 새우, 조개, 고추장, 간, 치즈, : 유해식품
		harmList.stream().filter( x -> targetIngres.contains((String)x)).forEach( x -> log.info("점검된 유해식품 : "+x + ", "));

		// 필터링된 유해식품
		List<String> filteringFoods = harmList.stream().filter( x -> targetIngres.contains((String)x)).map(x-> (String)x).toList();

		int filteringFoodLength = filteringFoods.size();
		log.info("filteringFoodLength : " + filteringFoodLength);

		// 요구사항 : 재료(INGREDIENTS) 내 유해식품 포함비율이 20% 이상 존재시 레시피(음식: DietVO) 리스트(result)에서 제거
		// 고혈압 유해음식이 100%일때 기존 음식(레시피) 재료(INGREDIENTS)내 20% 이상 있을 때 제거
		float harmfulFoodRatio = ((float)filteringFoodLength / harmList.size()) * 100;
		log.info("harmfulFoodRatio(%) : " + harmfulFoodRatio); // 21.73913 -> 20% 이상일 때 제거

		return harmfulFoodRatio;
	}

    /**
     * 중복 점검할 키워드 단어들 선별
     * ex) 라따뚜이, 라따뚜이 스프, 라따뚜이 전채요리 ===> 라따뚜이
     *
     * @param filters ex) String[] filters = {"차", "스프", "쑥국"};
     * @param foodName 음식명
     * @return
     */
    public String filterFood(String[] filters, String foodName)
	{
		int idx = 0;
		int len = 0;
		for (String str : filters) {

			 idx = foodName.indexOf(str) != -1 ? foodName.indexOf(str) : -1;
			 len = str.length();
			 foodName = idx != -1 ? foodName.substring(0, idx + len) : foodName;
		}

		return foodName;
	}

    /**
     * 분야별(주식, 빵, 음료/스프, 사이드디시(반찬), 샐러드) 추천음식들 선정
     * @param keywords : ex) 주식(파스타, 까르보), 음료/스프(음료, 쥬스, 주스, 우유, 차)
     * @return
     */
	public List<DietVO> recommendFoodList(Collection<String> keywords, String foodKind, Collection<String> anotherKeywords) {

		 List<DietVO> foodList = new ArrayList<>();

		// 포함 여부 검색
		for (String keyword : keywords) {
			foodList.addAll(dietDAO.findByFoodNameContaining(keyword)); //
		}

		// 특정분야(음료/스프) 조건적 키워드 추가
		if (foodKind.equals("음료/스프")) {
			for (String anotherKeyword : anotherKeywords) {
				foodList.addAll(dietDAO.findByFoodNameContaining(anotherKeyword));
			}	// 문제 : 음식명을 정규화 못함
	    }


		log.info("음식 개수 : " + foodList.size());

		// 각 분야별 유해요소 필터링
		List<DiseaseVO> list = (List<DiseaseVO>) diseaseDAO.findAll();

		// 1. for문 필터링 -> 4가지 질병 중  개인 건강정보에 기록된 질병에 한해서 필터링 한다.
		// 2. 사용자 질병 유무에 따라 달라짐
		// ex) 모든 질병에 해당전제
		// List<String> foodNames = new ArrayList<>(); //  기존 result

		for ( DiseaseVO diseaseVO : list) {

			log.info("diseaseVO : " + diseaseVO);
		}


		for ( DiseaseVO diseaseVO : list) {

			// 유해식품 필터링 ( 유해요소가 아닌 식품만 걸러냄) - 리스트화 for문 -> 질병별로 뺑뺑이

			// 질병별 필터링 EX)  고혈압
			foodListloop:
			for (DietVO dietVO : foodList) {

				// 개별 음식별 필터링
				// 기존 : 유해식품 존재시 DietVO 내 INGREDIENTS 빼기
				// 요구사항 : 재료(INGREDIENTS) 내 유해식품 포함비율이 20% 이상 존재시 레시피(음식: DietVO) 리스트(foodList)에서 제거
				// 각 질병별 한종목(질병)이라도 유해식품군 비율이 20%이상일 경우 제외
				log.info("유해식품 : " +diseaseVO.getHarmfulFood());
				log.info("재료: "+ dietVO.getIngredient());

				float harmfulRatio = 0;
				// 결측치 잡기 위한 에러
				if (diseaseVO.getHarmfulFood() != null && dietVO.getIngredient() != null) {
					harmfulRatio = this.checkHarmfulFood( diseaseVO.getHarmfulFood(), dietVO.getIngredient());
				}
				// 비율 적산
				log.info("harmfulRatio : " + harmfulRatio);

				 // 20% 일경우 유해식품으로 간주 -> 20
				if (harmfulRatio >= 20) {

					log.info("유해 식품 20% 초과 식품 : " + dietVO);

					// 유해식품을 리스트에서 삭제한다.
					foodList.remove(dietVO);
					break foodListloop;
				}
				else {
					log.info("유해 식품 20% 미만 식품 : " + dietVO);
				}

			}

			System.out.println("질병 : " + diseaseVO.getDisease());

			System.out.println("-----------------------------------------------------------------------------------");

		} // 이중 for문

		foodList.forEach(x -> { log.info("--추천식품 ({}) : {}", foodKind, x.getFoodName());} );

		return foodList;
	}

	/**
	 * 최종 분야별 음식 추천(낱개) : 분야별(주식, 빵, 음료/스프, 사이드디시(반찬), 샐러드) 추천음식 한개만 선정
	 *
	 * @param foodKind 음식 분야 ex) 분야별(주식, 음료/스프, 사이드디시(반찬), 샐러드)
	 * @param keywords 분야별 검색 키워드 ex) 주식 :  "파스타", "까르보나라"
	 * @param anotherKeywords 음료/스프 부가 키워드 ex) 차, 스프
	 * @return
	 */
	public DietVO recommendFood (String foodKind, Collection<String> keywords, Collection<String> anotherKeywords) {
		// String -> dietVO 바꾸기
		DietVO result = new DietVO(); // 초깃값

		// 불용어 ex) 궁중 보양식 타락죽  우유대신 라이스밀크로 만드는 타락죽  이유식으로 좋아요
		String[] stopWords =
	    	{"전분 없이 만드는 팽이버섯 개살스프덮밥",
	    	"도다리쑥국봄향기가 입안에 가득 차 오르다봄 보양식",
	    	"라따뚜이 만들기 저칼로리 다이어트식 가벼운 저녁메뉴 손님상차림 전채요리",
	    	"일본식 푸딩달걀찜 차완무시",
	    	"치킨 카차토레 이탈리아식 닭볶음탕",
	    	"남은 보쌈고기활용요리 일본식 차슈덮밥  차슈",
	    	"일본식 계란말이 타마고마끼  일본식 계란찜 차왕무시",
	    	"일본 가정식 명란 오차즈케",
	    	"일본식 계란찜 차완무시 만들기",
	    	"일본식 계란찜 차왕무시 푸딩같은 식감",
	    	"차슈덮밥 일본식 삼겹살덮밥 한그릇음식",
	    	"지중해 ✿차지키소스✿ 구운고기에 찍어 먹기│그릭요거트 사워크림 차이점",
	    	"궁중 보양식 타락죽  우유대신 라이스밀크로 만드는 타락죽  이유식으로 좋아요",
	    	"에어프라이어 계란찜 일본식 계란찜 차완무시 만드는법 영상",
	    	"웰빙식단 자연식으로 차린 밥상"};


		List<String> stopWordList = Arrays.asList(stopWords); // 배열 치환

		String[] filters = {};
		filters = keywords.toArray(filters); // 필터 변환

		List<DietVO> recommFoodList = this.recommendFoodList(keywords, foodKind, anotherKeywords);
		// 불용어 제거
		// list2.forEach(x -> {log.info("음료/스프 요소 : " + x);});
		// 불용어 이름만 제거
		List<String> foodNameList = recommFoodList.stream().map( x -> x.getFoodName()).filter(x -> !stopWordList.contains(x)).toList(); // stopwordlist 내 빠진것만

		//foodNameList.forEach(x -> {log.info("음식명 : " + x);}); // 불용어(비정규 음식명) 제거 예) 지중해 ✿차지키소스✿ 구운고기에 찍어 먹기│그릭요거트 사워크림 차이점 : 결과 X
		log.info("------------------------------------------------------------------------------------------");

		// 불용어 제거 최종
		List<DietVO> filteredList = recommFoodList.stream().filter(x -> foodNameList.contains(x.getFoodName())).toList();

		filteredList.forEach(x -> {log.info(foodKind + " 요소 : " + x);});

		// 한개의 음식 랜덤 선택  (0 ~ 1 사이 난수 * 크기)
		int selectedIndex = (int) (Math.random() * filteredList.size()-1);
		log.info("랜덤 인덱스 : " + selectedIndex);
		// 랜덤 후 선택
		//String foodName = filteredList.get(selectedIndex).getFoodName();
		result = filteredList.get(selectedIndex); // VO

		String foodName = result.getFoodName(); // dietVO 이름
		log.info("선정된 {} 음식 : {} ", foodKind, foodName); // 삼색채소, 냉파스타 초간단 일본식 명란파스타, 라비올리 만들기 이탈리아식 만두 파스타

		//result = dietService.filterFood(filters, foodName); 교정전
		result.setFoodName(this.filterFood(filters, foodName));

		log.info("최종 추천 {} : {}", foodKind, result);

		return result;
	}

	/**
	 * 최종 개인별 추천 레시피
	 * @return 최종 레시피
	 */
	public List<DietVO> recommendMeal(){

		// log.info("최종 레시피 추천");
		List<DietVO> meal = new ArrayList<>();

		// 주식
		Collection<String> keywords = new ArrayList<>(); // 초기화
		keywords.add("파스타");
		keywords.add("까르보나라");

		DietVO pasta = this.recommendFood("주식", keywords, null);
		// log.info("주식 : " + pasta); // 일본식 명란젓 파스타, 시금치브로컬리 파스타
		meal.add(pasta);

		////////////////////////////////////////////////////////////////////////////

		//  빵
		keywords = new ArrayList<>(); // 초기화
		keywords.add("빵");
		keywords.add("스콘");
		keywords.add("브레드");
		keywords.add("스틱");
		keywords.add("파이");
		keywords.add("샌드위치");
		keywords.add("베이글");

		DietVO bread = this.recommendFood("빵", keywords, null);
		// log.info("빵 : " + bread); // 홍삼 크린베리꿀빵, 삼색 브레드, 서양식 달걀파이

		meal.add(bread);

		////////////////////////////////////////////////////////////////////////////

		// 음료/스프 :
		keywords = new ArrayList<>();
		keywords.add("음료");
		keywords.add("쥬스");
		keywords.add("주스");
		keywords.add("우유");
		keywords.add("라따뚜이");
		keywords.add("쑥국");

		Collection<String> anotherKeywords = new ArrayList<>();
		anotherKeywords.add("차");
		anotherKeywords.add("스프");

		DietVO beaverSoup = this.recommendFood("음료/스프", keywords, anotherKeywords);
		// log.info("음료/스프 : " + beaverSoup); // 아몬드마늘스프 아호블랑꼬 스페인의 매력적인 지중해요리, 건강식 블루베리바나나쥬스, 대봉감주스

		meal.add(beaverSoup);

		////////////////////////////////////////////////////////////////////////////

		// 반찬(사이드디쉬) :
		keywords = new ArrayList<>();
		keywords.add("피클");
		keywords.add("라페");
		keywords.add("절임");

		DietVO sidedish = this.recommendFood("사이드디시(반찬)", keywords, null);
		// log.info("사이드디시(반찬) : " + sidedish); // 아스파라거스 초절임, 당근 라페 , 양파홍초절임

		meal.add(sidedish);

		////////////////////////////////////////////////////////////////////////////

		// 샐러드 :
		keywords = new ArrayList<>();
		keywords.add("샐러드");

		DietVO salad = this.recommendFood("샐러드", keywords, null);
		// log.info("샐러드 : " + salad); // 건강식 샐러드, 간단 지중해식 건강식단 오징어요리 유자청소스 오징어샐러드, 초계샐러드

		meal.add(salad);

		/////////////////////////////////////////////////////////////////////////////////////////////

		// 최종 추천
//		log.info("최종(주식) : "  + pasta);
//		log.info("최종(빵) : " + bread);
//		log.info("최종(음료/스프) : " + beaverSoup);
//		log.info("최종(사이드디시(반찬)) : " + sidedish);
//		log.info("최종(샐러드) : " + salad);

		return meal;
	}

    /*
	 *  여러 개의 Integer 값을 반복할 수 있는 자료형입니다. 즉, 이 자료형은 컬렉션(예: 리스트, 세트 등)을 포함하여
	 *   다양한 데이터 구조에서 사용될 수 있습니다. 이 표현은 유연성을 제공하지만,
	 *   메서드 내에서 사용할 때 실제로 어떤 자료형인지 파악하기 어렵기 때문에 상황에 따라
	 *   List<Integer> 또는 Set<Integer>와 같은 더 구체적인 타입을 사용하는 것이 좋습니다.
	 *

	public DietVO getDeleteByOriginalId(Iterable<Integer> ids) {
//
//		List<DietVO> dietIds = new ArrayList<>();
//		// 각 ID에 대해 DietVO를 찾아 리스트에 추가합니다.
//		ids.forEach(id -> dietDAO.findById(id).ifPresent(dietIds::add));
//
//		// null 값 제거 (ID가 존재하지 않을 경우)
//		dietIds.removeIf(dietid -> dietid == null);
//
//		// 중복된 ORIGINAL_ID 확인
//		Set<Integer> originalIds = new HashSet<>();
//		Set<Integer> duplicateOriginalIds = new HashSet<>();
//
//		for(DietVO diet : dietIds) {
//			int originalId = diet.getOriginalId(); // DietVO에 getOriginalId() 메서드가 있다고 가정
//			if(!originalIds.add(originalId)) {
//				duplicateOriginalIds.add(originalId);
//			}
//
//			if (!duplicateOriginalIds.isEmpty()) {
//		        throw new IllegalStateException("삭제할 수 없습니다: 중복된 ORIGINAL_ID가 존재합니다: " + duplicateOriginalIds);
//		    }
//			  // 중복이 없으면 삭제 로직을 진행합니다.
//			// dietDAO.deleteAll(dietIds);
//		}
//
//	}

	/*
	public void deleteById(Id id) {
	    List<Recipe> recipes = findAllById(Collections.singletonList(id));

	    // 중복된 ORIGINAL_ID 확인
	    Set<Long> originalIds = recipes.stream()
	                                    .map(Recipe::getOriginalId)
	                                    .collect(Collectors.toSet());

	    if (originalIds.size() > 1) {
	        throw new IllegalStateException("Cannot delete: More than one recipe with this ORIGINAL_ID");
	    }

	    // 삭제 로직
	    // repository.deleteById(id);
	}*/

	/*
	 * public List<String> getIngredientsById(int id) { // 예를 들어, ID에 해당하는 재료를
	 * 데이터베이스에서 가져오는 로직 dietDAO.findById(id); return dietDAO.getIngredients(); // 예:
	 * "아보카도 1개적양파 1/3개토마토 1개..." }
	 */

	/** 11.12
	 * 메인 질병 선택시 n개 추천 레시피 (해로운 음식 0개인 레시피)
	 *
	 * @param disease 질병
	 * @param recommSize 추천 음식 갯수
	 * @return
	 */
	public List<Integer> getRecomm(String disease, int recommSize) {

		List<Integer> recommList = new ArrayList<>();

		List<DietVO> diets = this.getAllDiets();

		// 질병별로 해로운 음식
		String filter = diseaseDAO.findById(disease).get().getHarmfulFood();

		String filters[] = filter.split(", ");

		// 음식ID, 유해식품 포함 수
		Map<Integer, Integer> map = new HashMap<>();

		// 음식별 유해식품 갯수 점검
		for (DietVO dietVO : diets) {

			int cnt = 0; // 유해식품 포함 갯수

			if (dietVO.getIngredient() == null || dietVO.getIngredient().trim().equals("")) {

				continue;

			} else {

				for (String s : filters) {

					if (dietVO.getIngredient().contains(s)) {
						// log.info("포함 유해식품 : " + s);
						cnt++;
					}
				} // for

				map.put(dietVO.getId(), cnt);
			}

		} // for

		Map<Integer, Integer> recommMap = new HashMap<>();

		// 유해식품이 없는게 최우선 -> 유해식품이 0이 아닌게 없다면 유해식품이 1인거에서 나열
		// 유해식품이 0인 레시피 검색
		for (int key : map.keySet()) {

			int value = map.get(key);

			if (value == 0) {
				recommMap.put(key, value);
			}
		}

		// 질병별 유해식품 없는 추천 식품
		// log.info(disease + " 유해식품 없는 추천 식품 현황 : " + recommMap.size());
//		recommMap.entrySet().forEach(x -> {
//			log.info("" + x);
//		});

		recommList.addAll(recommMap.keySet());

		Collections.shuffle(recommList); // 임의로 혼합

		return recommList.subList(0, recommSize);
	}

	// 11.12
	@Transactional
	public void deleteById(int id) {
		dietDAO.deleteById(id);
	}

}
