package com.dementia.memoryTable.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class RecipeDAOImpl implements RecipeDAO {

	@Autowired
	SqlSession sqlSession; // MyBatis Session 객체

	@Override
	public List<Map<String, Object>> selectRecipeBySearchingAndPaging(String searchKey, String searchWord, int page,
			int limit, String ordering) {

		Map<String, Object> map = new HashMap<>();
		map.put("searchKey", searchKey);
		map.put("searchWord", searchWord);
		map.put("page", page);
		map.put("limit", limit);
		map.put("ordering", ordering);

		log.info("인자 출력-2 : ");
		map.entrySet().forEach(x -> {log.info(x + ""); });

		return sqlSession.selectList("mapper.RecipeMapper.selectRecipeBySearchingAndPaging", map);
	}

	@Override
	public int selectCountBySearching(String searchKey, String searchWord) {

		Map<String, Object> map = new HashMap<>();
		map.put("searchKey", searchKey);
		map.put("searchWord", searchWord);

		return (int)sqlSession.selectOne("mapper.RecipeMapper.selectCountBySearching", map);
	}

	// 11.01 gnb 검색 기능 추가
	@Override
	public List<Map<String, Object>> gnbRecipeBySearchingAndPaging(String searchWord, int page, int limit, String ordering) {

		Map<String, Object> map = new HashMap<>();
		map.put("searchWord", searchWord);
		map.put("page", page);
		map.put("limit", limit);
		map.put("ordering", ordering);

		log.info("인자 출력-3 : ");
		map.entrySet().forEach(x -> {log.info(x + ""); });

		return sqlSession.selectList("mapper.RecipeMapper.gnbRecipeBySearchingAndPaging", map);
	}

	// 11.01 gnb 검색 기능 추가
	@Override
	public int gnbCountBySearching(String searchWord) {

		Map<String, Object> map = new HashMap<>();
		map.put("searchWord", searchWord);

		return (int)sqlSession.selectOne("mapper.RecipeMapper.gnbCountBySearching", map);
	}

}
