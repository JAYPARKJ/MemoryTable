package com.dementia.memoryTable.domain;

import java.util.ArrayList;
import java.util.List;

public class IngredientBox {
    private List<String> ingredients;

    public IngredientBox(List<String> ingredients) {
        this.ingredients = ingredients;
    }

    public List<Ingredient> getParsedIngredients() {
        List<Ingredient> ingredientList = new ArrayList<>();

        // 단위로 사용할 가능성이 있는 문자열들 (개, 대, 장 등)
        String[] possibleUnits = {"개", "대", "잎", "조각", "알", "t", "장", "g", "ml", "스푼", "컵"};

        for (String ingredient : ingredients) {
            String currentName = ""; // 재료 이름
            String currentQuantity = ""; // 양

         // 각 재료 문자열에 대해 처리
            for (int i = 0; i < ingredient.length(); i++) {
                char ch = ingredient.charAt(i);
	            // 숫자나 한글 단위가 나오면 양으로 인식
	                if (Character.isDigit(ch) || containsUnit(Character.toString(ch), possibleUnits)) {
	                    currentQuantity += ch; // 양에 해당하는 부분을 쌓아줌
	                } else {
	                // 양이 아직 없다면 이름에 계속 추가
	                if (currentQuantity.isEmpty()) {
	                    currentName += ch;
	                } else {
	                    // 이미 양이 시작되었으면 새로운 재료로 인식
	                    ingredientList.add(new Ingredient(currentName.trim(), currentQuantity.trim()));
	                    currentName = "" + ch; // 새로운 재료 이름 시작
	                    currentQuantity = ""; // 양 초기화
	                }
	            }
	        }

            // 마지막 재료도 추가
            if (!currentName.isEmpty()) {
                ingredientList.add(new Ingredient(currentName.trim(), currentQuantity.trim()));
            }
        }

        return ingredientList;
    }
    // 주어진 문자열이 단위를 포함하고 있는지 확인하는 함수
    private boolean containsUnit(String str, String[] units) {
        for (String unit : units) {
            if (str.startsWith(unit)) {
                return true;
            }
        }
        return false;
    }

    // Getter and Setter
}