package com.dementia.memoryTable.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dementia.memoryTable.domain.MemberDTO;
import com.dementia.memoryTable.domain.MemberVO;
import com.dementia.memoryTable.service.MemberService;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("member")
@Slf4j
public class MemberJoinController {
	@Autowired
	MemberService memberService;
	BCryptPasswordEncoder bCryptPasswordEncoder;

	@PostMapping("joinUser")
	// @ResponseBody
	public String joinUser(@ModelAttribute("memberDTO") MemberVO memberVO, Model model) {
		log.info("회원 가입 처리 : {}", memberVO);
		String msg = ""; // 저장 성공/실패 메시지
		String path = ""; // 처리 후 이동 페이지
		String success = ""; // 가입 성공 여부

		bCryptPasswordEncoder = new BCryptPasswordEncoder();
		String encPw = bCryptPasswordEncoder.encode(memberVO.getPw());
		memberVO.setPw(encPw);

		// 회원 사용가
		memberVO.setEnabled(1);

		// return memberVO.toString();

		if (memberService.insertMember(memberVO) == true) {
			msg = "회원가입에 성공하셨습니다.";
			success = "success";
			path = "/loginForm";
		} else {
			msg = "회원가입에 실패하였습니다.";
			success = "error";
			path = "/join_user";
		}
		model.addAttribute("msg", msg);
		model.addAttribute("success", success);
		// model.addAttribute("path", path);

		return path; // result.html (thymeleaf)'
	}

	@PostMapping("joinAdmin")
	// @ResponseBody
	public String joinAdmin(@ModelAttribute("memberDTO") MemberVO memberVO, Model model) {
		log.info("관리자가입 처리 : {}", memberVO);
		String msg = ""; // 저장 성공/실패 메시지
		String path = ""; // 처리 후 이동 페이지

		bCryptPasswordEncoder = new BCryptPasswordEncoder();
		String encPw = bCryptPasswordEncoder.encode(memberVO.getPw());
		memberVO.setPw(encPw);

		// 회원 사용가
		memberVO.setEnabled(1);

		// return memberVO.toString();

		if (memberService.insertMemberAdmin(memberVO) == true) {
			msg = "회원가입에 성공하셨습니다.";
			path = "/loginForm";
		} else {
			msg = "회원가입에 실패하였습니다.";
			path = "/join_admin";
		}
		model.addAttribute("msg", msg);
		model.addAttribute("path", path);

		return "path"; // result.html (thymeleaf)'
	}
}
