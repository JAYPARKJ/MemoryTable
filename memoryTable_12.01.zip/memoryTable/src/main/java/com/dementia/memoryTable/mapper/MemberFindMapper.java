package com.dementia.memoryTable.mapper;

import org.springframework.data.repository.query.Param;

public interface MemberFindMapper {

	public String findId(@Param("name") String name, @Param("email") String email);
}
