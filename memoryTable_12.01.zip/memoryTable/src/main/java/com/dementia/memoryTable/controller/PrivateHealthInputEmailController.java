package com.dementia.memoryTable.controller;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.dementia.memoryTable.domain.CustomUser;
import com.dementia.memoryTable.domain.HealthVO;
import com.dementia.memoryTable.domain.MemberVO;
import com.dementia.memoryTable.domain.naverAndGoogle.OAuthVO;
import com.dementia.memoryTable.service.DietService;
import com.dementia.memoryTable.service.HealthFilterService;
import com.dementia.memoryTable.service.MemberService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class PrivateHealthInputEmailController {

	@Value("${image.repo.location}")
	String filePath;

	@Autowired
	MemberService memberService;

	@Autowired
	DietService dietService;

	@Autowired
	HealthFilterService healthFilterService;

	@GetMapping("/member/privateHealthInput/email")
	public String privateHealthInputEmail(Model model) {

		// Spring Security Principal(Session) 조회
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		log.info("principal : {}", principal);

		OAuthVO oAuthVO = null;
		String email = null;

		if (principal instanceof DefaultOAuth2User) {
			DefaultOAuth2User oauthUser = (DefaultOAuth2User) principal;
			email = oauthUser.getAttribute("email"); // 이메일 속성 가져오기
			oAuthVO = new OAuthVO(); // OAuthVO 객체 생성
			oAuthVO.setName(oauthUser.getAttribute("name")); // 이름 속성 설정
			log.info("OAuth2 User email : {}", email);
		} else if (principal instanceof CustomUser) {
			CustomUser customUser = (CustomUser) principal;
			email = customUser.getUsername(); // 사용자 이름이 이메일일 경우
		}

		if (email != null) {
            model.addAttribute("email", email);
            model.addAttribute("age", 0); // 기본값으로 0 설정

        } else {
            log.error("사용자 정보를 찾을 수 없습니다.");
        }

		return "/member_health/private_health_input_google_naver";
	}

	// 건강정보폼 입력 처리
	@PostMapping("/member/privateHealthInputEmailAction")
	public String privateHealthInputAction(Model model, @ModelAttribute HealthVO healthVO) {

		log.info("privateHealthInputAction : " + healthVO);

		// 건강 정보 폼(healthVO) 저장 11.01
		HealthVO saveHealthVO = healthFilterService.saveHealthForm(healthVO);

		return "redirect:/member/privateHealthInput/email";
	}
}