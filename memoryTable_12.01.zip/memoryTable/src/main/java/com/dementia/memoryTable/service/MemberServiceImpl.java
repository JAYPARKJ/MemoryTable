package com.dementia.memoryTable.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.dementia.memoryTable.domain.HealthVO;
import com.dementia.memoryTable.domain.MemberDTO;
import com.dementia.memoryTable.domain.MemberVO;
import com.dementia.memoryTable.domain.Role;
import com.dementia.memoryTable.domain.naverAndGoogle.OAuthVO;
import com.dementia.memoryTable.repository.HealthDAO;
import com.dementia.memoryTable.repository.MemberDAO;
import com.dementia.memoryTable.repository.OAuthUserMyBatisDAO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MemberServiceImpl implements MemberService {

	// howto-1)
	@Autowired
	// DataSourceTransactionManager dsTxManager;
	PlatformTransactionManager dsTxManager;

	// howto-2)
//	private final PlatformTransactionManager dsTxManager;
//
//	public MemberServiceImpl(PlatformTransactionManager dsTxManager) {
//		this.dsTxManager = dsTxManager;
//	}

	// howto-1)
	// @Autowired
	// TrasactionTemplate txTemplate;

	// howto-2)
	TransactionTemplate txTemplate;

	@Autowired
	void setTransactionTemplate(PlatformTransactionManager txManager) {
		this.txTemplate = new TransactionTemplate(txManager);
	}

	@Autowired
	MemberDAO memberDAO;

	@Autowired
	HealthDAO healthDAO;

	@Autowired
	OAuthUserMyBatisDAO oAuthUserMyBatisDAO;

	@Transactional(readOnly = true)
	@Override
	public MemberVO selectMemberById(String id) {

		return memberDAO.selectMemberById(id);
	}

	@Transactional(readOnly = true)
	@Override
	public List<MemberVO> selectMembersByPaging(int page, int limit) {

		return memberDAO.selectMembersByPaging(page, limit);
	}

	@Transactional(readOnly = true)
	@Override
	public List<MemberVO> selectAllMembers() {

		return memberDAO.selectAllMembers();
	}

	@Override
	public boolean insertMember(MemberVO memberVO) {

		return txTemplate.execute(status -> {

				boolean result = false;

				// 회원정보 생성
				try {

					log.info("기존 회원 존재여부 : " + memberDAO.hasMemberByFld("ID", memberVO.getId()));

					// 기존 회원 존재 여부
					if (memberDAO.hasMemberByFld("ID", memberVO.getId()) == true) {
						throw new Exception("중복되는 회원정보가 존재합니다.");
					}

					log.info("-- memberVO : " + memberVO);

					result = memberDAO.insertMember(memberVO);
				} catch (Exception e) {
					result = false;
					log.error("MemberService.insertMember 에러 : " + e);
					status.setRollbackOnly();
				}

				// 버그 패치 : 상위 CRUD 수행시 중복회원 있을 경우 에러 리턴
				// 상위 CRUD 실행시 에러 없을 경우만 아래 구문 실행
				if (result == true) {

					// 회원 롤(Role) 생성
					try {
						// 중요) 버그 패치
						// 기존 회원 존재 여부 : 기존회원이 존재해야 롤 추가 가능 !
						if (memberDAO.hasMemberByFld("ID", memberVO.getId()) == false) {
							throw new Exception("회원정보가 존재하지 않습니다.");
						}

						result = memberDAO.insertRole(memberVO.getId(), "ROLE_USER");
					} catch (Exception e) {
						result = false;
						log.error("MemberService.insertMember(Role) 에러 : " + e);
						status.setRollbackOnly();
					}
				} // if

				return result;
			}
		);
	}

	@Override
	public boolean insertMemberAdmin(MemberVO memberVO) {

		return txTemplate.execute(status -> {

				boolean result = false;

				// 회원정보 생성
				try {

					log.info("기존 회원 존재여부 : " + memberDAO.hasMemberByFld("ID", memberVO.getId()));

					// 기존 회원 존재 여부
					if (memberDAO.hasMemberByFld("ID", memberVO.getId()) == true) {
						throw new Exception("중복되는 회원정보가 존재합니다.");
					}

					log.info("-- memberVO : " + memberVO);

					result = memberDAO.insertMember(memberVO);
				} catch (Exception e) {
					result = false;
					log.error("MemberService.insertMemberAdmin 에러 : " + e);
					status.setRollbackOnly();
				}

				// 버그 패치 : 상위 CRUD 수행시 중복회원 있을 경우 에러 리턴
				// 상위 CRUD 실행시 에러 없을 경우만 아래 구문 실행
				if (result == true) {

					// 회원 롤(Role) 생성
					try {
						// 중요) 버그 패치
						// 기존 회원 존재 여부 : 기존회원이 존재해야 롤 추가 가능 !
						if (memberDAO.hasMemberByFld("ID", memberVO.getId()) == false) {
							throw new Exception("회원정보가 존재하지 않습니다.");
						}

						result = memberDAO.insertRole(memberVO.getId(), "ROLE_ADMIN");
					} catch (Exception e) {
						result = false;
						log.error("MemberService.insertMemberAdmin(Role) 에러 : " + e);
						status.setRollbackOnly();
					}
				} // if

				return result;
			}
		);
	}

	@Override
	public boolean updateMember(MemberVO memberVO) {

		return txTemplate.execute(new TransactionCallback<Boolean>() {

			@Override
			public Boolean doInTransaction(TransactionStatus status) {

				boolean result = false;

				try {
					// 기존 회원 존재 여부
					if (memberDAO.hasMemberByFld("ID", memberVO.getId()) == false) {
						throw new Exception("수정할 회원정보가 존재하지 않습니다.");
					}

					result = memberDAO.updateMember(memberVO);

				} catch (Exception e) {
					result = false;
					log.error("MemberService.updateMember 오류 : " + e);
					status.setRollbackOnly();
				}

				return result;
			}

		});
	}

	@Override
	public boolean deleteMember(String id) {

		return txTemplate.execute(new TransactionCallback<Boolean>() {

			@Override
			public Boolean doInTransaction(TransactionStatus status) {

				boolean result = false;

				try {
					// 기존 회원 존재 여부
					if (memberDAO.hasMemberByFld("ID", id) == false) {
						throw new Exception("삭제할 회원정보가 존재하지 않습니다.");
					}

					if (memberDAO.deleteRoles(id) == true &&
					    memberDAO.deleteMemberById(id) == true) {
						result = true;
					}

				} catch (Exception e) {
					result = false;
					log.error("MemberService.deleteMember 오류 : " + e);
					status.setRollbackOnly();
				}

				return result;
			}

		});
	}

	@Transactional(readOnly = true)
	@Override
	public boolean hasMemberByFld(String fld, String val) {
		return memberDAO.hasMemberByFld(fld, val);
	}

	@Transactional(readOnly = true)
	@Override
	public boolean hasMemberForUpdate(String id, String fld, String val) {
		return memberDAO.hasMemberForUpdate(id, fld, val);
	}

	@Transactional(readOnly = true)
	@Override
	public int selectCountAll() {
		return memberDAO.selectCountAll();
	}

	@Transactional(readOnly = true)
	@Override
	public List<Map<String, Object>> selectMembersBySearchingAndPaging(String searchKey, String searchWord, int page,
			int limit, String isLikeOrEquals, String ordering) {
		return memberDAO.selectMembersBySearchingAndPaging(searchKey, searchWord, page, limit, isLikeOrEquals, ordering);
	}

	@Override
	public boolean updateRoles(String id, boolean roleUserYn, boolean roleAdminYn) {

		boolean result = false;

		// 먼저 해당 id의 등급(role)이 있는지 점검
		// 있으면 삽입하지 않고 그대로 두고, 없으면 롤(role) 삽입

		// 경우의 수 : 대부분 회원(ROLE_USER) 이상의 롤을 보유하고 있기 때문에 이런 경우는
		// 관리자 여부를 우선 점검하는 것이 유효함.

		List<String> roles = memberDAO.selectRolesById(id);

		// 회원(ROLE_USER)이면서 관리자 권한이 없는 경우
		if (roleAdminYn == true &&
			roles.contains("ROLE_USER") == true &&
			roles.contains("ROLE_ADMIN") == false)
		{
			log.info("관리자 권한 할당");

			Role role = new Role();
			role.setUsername(id);
			role.setRole("ROLE_ADMIN");

			result = this.insertRole(role);
		}
		// 회원(ROLE_USER)이면서 관리자 권한을 회수할 경우(관리자 권한 삭제)
		else if (roleAdminYn == false &&
				 roles.contains("ROLE_USER") == true &&
				 roles.contains("ROLE_ADMIN") == true)
		{
			log.info("관리자 권한 회수");

			String role = "ROLE_ADMIN";
			result = this.deleteRoleById(id, role);
		}

		return result;
	}

	@Transactional
	@Override
	public boolean insertRole(Role role) {

		boolean result = false;

		try {
			memberDAO.insertRole(role.getUsername(), role.getRole());
			result = true;
		} catch (Exception e) {
			result = false;
			log.error("MemberService.insertRole : {}", e);
			e.printStackTrace();
		} //

		return result;
	}

	@Transactional
	@Override
	public boolean deleteRoleById(String id, String role) {

		boolean result = false;

		try {
			memberDAO.deleteRoleById(id, role);
			result = true;
		} catch (Exception e) {
			log.error("MemberService.deleteRoleById : {}", e);
			e.printStackTrace();
		}

		return result;
	}

	@Transactional
	@Override
	public boolean changeEnabled(String id, int enabled) {

		boolean result = false;

		try {
			memberDAO.changeEnabled(id, enabled);
			result = true;
		} catch (Exception e) {
			result = false;
			log.error("MemberService.changeEnabled : {}", e);
			e.printStackTrace();
		} //

		return result;
	}

	@Transactional(readOnly = true)
	@Override
	public int selectCountBySearching(String searchKey, String searchWord) {
		return memberDAO.selectCountBySearching(searchKey, searchWord);
	}

	// 10.04
	@Transactional(readOnly = true)
	@Override
	public OAuthVO selectMemberByEmailAndAuthVendor(String email, String authVendor) {
		return oAuthUserMyBatisDAO.selectOAuthVO(email, authVendor);
	}

	// 10.04
	@Override
	public boolean deleteOAuth(String email, String authVendor) {

		return txTemplate.execute(new TransactionCallback<Boolean>() {

			@Override
			public Boolean doInTransaction(TransactionStatus status) {

				boolean result = false;

				try {
					// 기존 회원 존재 여부
					if (oAuthUserMyBatisDAO.selectOAuthVO(email, authVendor) == null) {
						throw new Exception("삭제할 회원정보가 존재하지 않습니다.");
					}

					try {
						oAuthUserMyBatisDAO.deleteOAuthVO(email, authVendor);
						result = true;
					} catch (Exception e) {
						result = false;
						log.error("MemberService.deleteOAuthVO - 1 오류 : " + e);
						status.setRollbackOnly();
					}

				} catch (Exception e) {
					result = false;
					log.error("MemberService.deleteOAuthVO - 2 오류 : " + e);
					status.setRollbackOnly();
				}

				return result;
			}

		});
	} //

	// 10.11 아이디찾기
	@Transactional(readOnly = true)
	@Override
	public String findId(String name, String email) {
		return memberDAO.findId(name, email);
	}

	// 10.16 임시비밀번호
	@Override
	public int updatePwd(MemberVO memberVO) {
		return memberDAO.updatePwd(memberVO);
	}

}