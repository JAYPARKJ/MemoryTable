package com.dementia.memoryTable.domain.naverAndGoogle;

import java.util.Map;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Setter
@Slf4j
public class OAuthAttributes {

	private Map<String, Object> attributes;
	private String nameAttributeKey;
	private String name;
	private String email;
	private String mobile;
	
	private String authVendor; // 추가
	
	@Builder
	public OAuthAttributes(Map<String, Object> attributes, String nameAttributeKey, String name, String email, String mobile, String authVendor) {
		this.attributes = attributes;
		this.nameAttributeKey = nameAttributeKey;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.authVendor = authVendor; // 추가
	}
	
	public static OAuthAttributes of(String registrationId, String userNameAttributeName, Map<String, Object> attributes) {
		OAuthAttributes result = null;
		
		if ("naver".equals(registrationId)) {
			result = ofNaver("id", attributes);
		}
		else if("google".equals(registrationId)) {
			result = ofGoogle(userNameAttributeName, attributes);
		}
		
		log.info("registrationId : " + registrationId);
		
		result.setAuthVendor(registrationId);
		
		return result;
	}
	
	// 코드 활성화
	private static OAuthAttributes ofGoogle(String userNameAttributeName, Map<String, Object> attributes) {
		return OAuthAttributes.builder()
							.name((String) attributes.get("name"))
							.email((String) attributes.get("email"))
							.mobile((String) attributes.get("mobile"))
							.attributes(attributes)
							.nameAttributeKey(userNameAttributeName)
							.build();
	}
	
	@SuppressWarnings("unchecked")
	private static OAuthAttributes ofNaver(String userNameAttributeName, Map<String, Object> attributes) {
		Map<String, Object> response = (Map<String, Object>) attributes.get("response");
		
		return OAuthAttributes.builder()
							.name((String) response.get("name"))
							.email((String) response.get("email"))
							.mobile((String) response.get("mobile"))
							.attributes(response)
							.nameAttributeKey(userNameAttributeName)
							.build();
	}
	
	public OAuthVO toEntity() {
		return OAuthVO.builder()
					.name(name)
					.email(email)
					.mobile(mobile)
					.authVendor(authVendor)
					.role(OAuthRole.USER)
					.build();
	}
}
