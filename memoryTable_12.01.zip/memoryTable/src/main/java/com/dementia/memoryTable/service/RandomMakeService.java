package com.dementia.memoryTable.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RandomMakeService {

	// 이메일 인증번호 4자리 생성
	public String makeRandom() {

		String result = "";

		for (int i = 0; i < 4; i++) {
			result += (int)(Math.random() * 10);
		}

		return result;
	}

	public String random(String arr[]) {
		List<Object> arrList = new ArrayList<>();
		arrList.addAll(Arrays.asList(arr));
		Collections.shuffle(arrList);

		return (String)arrList.get(0);
	}

	private static void generatePermutations(int[] arr, int start, List<List<Integer>> results) {
		if (start >= arr.length) {
			List<Integer> perm = new ArrayList<>();
			for (int num : arr) {
				perm.add(num);
			}
			results.add(perm);
			return;
		}

		for (int i = start; i < arr.length; i++) {
			swap(arr, start, i);
			generatePermutations(arr, start + 1, results);
			swap(arr, start, i); // backtrack
		}
	}

	private static void swap(int[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	private static List<Integer> makeArr() {

		int[] numbers = { 1, 2, 3, 4 }; // 사용할 숫자
		List<List<Integer>> results = new ArrayList<>();
		generatePermutations(numbers, 0, results);

		List<Integer> returnVal = null;

		for (List<Integer> permutation : results) {
			int sum = permutation.stream().mapToInt(Integer::intValue).sum();
			if (sum >= 8 && sum <= 16) {
				returnVal = permutation;
			}
		}

		int idx = (int)(Math.random() * results.size());
		log.info("idx : " + idx);
		return results.get(idx);
	}

	// 임시 비밀번호 생성
	// 정규식 : (?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\\W).{8,16}
	// 8~16자/문자,숫자,특수문자 각 1개 이상
	public static String tempPassword(){

		String arrUpper[] = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N",
				"O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};

		String arrLower[] = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n",
				"o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};

		String arrPunc[] = {"<", ">", "$", "#", "!", "?", "*", "@", "&", "^"};

		List<Integer> perm = makeArr(); // ex) [4, 2, 1, 3] 출력

		String ch1; // 숫자 48~57
//		String ch2; // 소문자 97~122
//		String ch3; // 대문자
//		String ch4; // 특수문자

		List<String> tempPwdList = new ArrayList<>();

		// 랜덤 숫자
		for (int i = 0; i < perm.get(0); i++) {
			ch1 = (char)(48 + (int)(Math.random() * 10)) + ""; // 0 ~ 9  (48~57)
			tempPwdList.add(ch1);
		}

		// 랜덤 소문자
		List<String> tempLowerList = Arrays.asList(arrLower);
		Collections.shuffle(tempLowerList);

		for (int i = 0; i < perm.get(1); i++) {
			tempPwdList.add(tempLowerList.get(i));
		}

		// 랜덤 대문자
		List<String> tempUpperList = Arrays.asList(arrUpper);
		Collections.shuffle(tempUpperList);

		for (int i = 0; i < perm.get(2); i++) {
			tempPwdList.add(tempUpperList.get(i));
		}

		// 랜덤 특수문자
		List<String> tempPuncList = Arrays.asList(arrPunc);
		Collections.shuffle(tempPuncList);

		for (int i = 0; i < perm.get(3); i++) {
			tempPwdList.add(tempPuncList.get(i));
		}

		log.info("tempPwdList : " + tempPwdList);

		String str ="";

		// 문자 배열 길이의 값을 랜덤으로 8~16개를 뽑아 구문을 작성함
		for (int i = 0; i < tempPwdList.size(); i++) {
			str += tempPwdList.get(i);
		}

		return str;
	}


//	public static String tempPassword(){
//		char[] charSet = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F',
//				'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
//
//		String str = "";
//
//		// 문자 배열 길이의 값을 랜덤으로 10개를 뽑아 구문을 작성함
//		int idx = 0;
//		for (int i = 0; i < 10; i++) {
//			idx = (int) (charSet.length * Math.random());
//			str += charSet[idx];
//		}
//
//
//		return str;
//	}
}
