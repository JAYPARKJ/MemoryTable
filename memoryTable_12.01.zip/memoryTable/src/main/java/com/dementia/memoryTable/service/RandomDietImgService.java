package com.dementia.memoryTable.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.dementia.memoryTable.domain.DietVO;
import com.dementia.memoryTable.repository.DietDAO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RandomDietImgService {

	@Autowired
	DietDAO dietDAO;


	@Value("${image.repo.location}")
	String imgLocation;

	/**
	 * 랜덤이미지 추출
	 * - 전체 이미지 중 5개 추출
	 *
	 * @return 이미지 리스트
	 */
	public List<Map<String, Object>> randomDietImg() {

		// List<Map<String, Object>> imgs = new ArrayList<>();

		// 랜덤 결정시 DEMENTIA_DIET_TBL ID에 최댓값(MAX VALUE) 범주 내 고름 -> 항상 레코드라 볼순 없다(불연속적인 데이터)
		// 1600개 -> ID만 1600개  List화 랜덤 이미지 선발
		// 랜덤 선발 시 SET의 길이 범주 내(Math.random())을 돌린다. -> 번호 정확한 데이터 추출
		// List<DietVO> ite = (List)dietDAO.findAll();
		// 100개 추출(테스트용 - 성능저하 방지)
		List<DietVO> ite = dietDAO.findAll(PageRequest.of(0, 100)).getContent(); // 100개만 가져오기 -> 제일 빠름
		/*  imgs1 = ite.stream()
			  .map(x -> Map.of("imgs", "/recipeImg/" + x.getFoodImg(), "id", x.getId()))
				  .collect(Collectors.toList());*/

		List<Map<String, Object>> imgs = ite.stream()
										    .map(x -> {
										        Map<String, Object> map = new HashMap<>();
										        map.put("imgs", "/recipeImg/" + x.getFoodImg());
										        map.put("id", x.getId());
										        map.put("dietName", x.getDietName()); // 10.24 추가
										        map.put("foodName", x.getFoodName()); // 10.24 추가
										        return map;
										    })
										    .collect(Collectors.toList());

		// imgs.addAll(ite.stream().map(x -> "/recipeImg/" + x.getFoodImg()).toList());


		// refresh할때 마다 5개 랜덤으로 이미지 추출 - shuffle
		log.info("랜덤음식 이미지 조회");
		// 랜덤화 (그때마다 달라짐)
		Collections.shuffle(imgs);
		String tmp = "";
		for(int i = 1; i<=5; i++) {
			tmp +=  imgs.get(i) + ", ";
		}
		log.info("tmp : " + tmp);

		return imgs.subList(0, 5);
	}
}
