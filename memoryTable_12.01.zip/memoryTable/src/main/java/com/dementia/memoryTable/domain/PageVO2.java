package com.dementia.memoryTable.domain;

import lombok.Data;

@Data
public class PageVO2 {

	/** 시작 페이지 */
	private int startPage;

	/** 마지막 페이지 */
	private int endPage;

	/** 총 페이지 수 */
	private int maxPage;

	/** 현재 페이지 */
	private int currPage;

	/** 총 인원/게시글 수 */
	private int listCount;

	/** 이전 페이지 */
	private int prePage;

	/** 다음 페이지 */
	private int nextPage;

	public static int getMaxPage(int listCount, int limit) {
		return (int) ((double) listCount / limit + 0.95); // 0.95를 더해서 올림 처리
	}

	// 현재 페이지 -> 페이지 전개 -> startPage
	// 1 -> 1,2,3 -> 1 제외후 +1씩 증가
	// 2 -> 1,2,3 -> 1
	// 3 -> 2,3,4 -> 2
	// 4 -> 3,4,5 -> 3
	// 5 -> 4,5,6 -> 4
	// 6 -> 5,6,7 -> 5

	/**
	 * 시작 페이지 결정
	 *
	 * @param currPage    현재페이지
	 * @param pagePerList 리스트 당 페이지 개수 ex) 1,2,3... 3개
	 * @param limit       페이지당 게시글 수
	 * @return
	 */
	/*
	 * public static int getStartPage(int currPage, int limit) { return (((int)
	 * ((double)currPage / limit + 0.9)) - 1) * limit + 1; }
	 */
	public static int getStartPage(int currPage, int pagePerList, int limit) {
		int result;
		if (pagePerList > 1) {
			result = currPage == 1 ? 1 : currPage - 1;
		} else {
			// 1P일때
			result = (((int) ((double) currPage / limit + 0.9)) - 1) * limit + 1;
		}

		return result;
	} //

	// 현재 페이지 -> 페이지 전개 -> endPage
	// 1 -> 1,2,3 -> 3
	// 2 -> 1,2,3 -> 3
	// 3 -> 2,3,4 -> 4
	// 4 -> 3,4,5 -> 5
	// 5 -> 4,5,6 -> 6
	// 6 -> 5,6,7 -> 7
	// ...
	//
	// 11 -> 10,11,12 -> 12
	// 12 -> 11,12,13 -> 13
	// 13 -> 11,12,13 -> 13
	/**
	 * 마지막 페이지
	 *
	 * @param currPage    현재 페이지
	 * @param maxPage     총 페이지 수
	 * @param pagePerList 리스트 당 페이지 개수 ex) 1,2,3... 3개
	 * @return
	 */
	public static int getEndPage(int currPage, int maxPage, int pagePerList) {

		return currPage == 1 ? pagePerList : currPage == maxPage ? maxPage : currPage + 1;
	}

} //