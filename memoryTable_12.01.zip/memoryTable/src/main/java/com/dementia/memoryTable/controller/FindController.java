package com.dementia.memoryTable.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.dementia.memoryTable.service.MemberService;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("find")
@Slf4j
public class FindController {
	
	@Autowired
	MemberService memberService;
	
	@GetMapping(value="/result")
	// @ResponseBody
	public String resultFindId (@RequestParam("name") String name,
								@RequestParam("email") String email, Model model) {
		
		log.info("result findId : ");
		String id = memberService.findId(name, email);
		
		String errMsg = "";
		String movePage = "";
		
		errMsg = id == null ? "해당되는 아이디가 없습니다." : "아이디가 존재합니다.";
		movePage = id == null ? "/findId": "/foundId";
		
		model.addAttribute("errMsg", errMsg);
		model.addAttribute("movePage", movePage + "?id=" + id);
	
		return "/error/error";
	}
}
