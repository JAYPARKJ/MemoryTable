package com.dementia.memoryTable.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

/**
 *  질병에 따른 영양소 요구량을 계산하여 환자에게 적절한 영양 관리 정보를 제공하려는 목적
 *  특정 질병에 대한 표준 요구량을 기반으로 하여, 개인의 신체 조건(신장, 체중, 나이, 성별)에 맞춰 필요한 영양소의 양을 계산
 *
 */
@Service
@Slf4j
public class HealthDiagnosticServiceImpl implements HealthDiagnosticService {

	// 로직 : 성별에 따른 개인의 에너지 요구량(EER)을 계산
    @Override
    public int calculateRDA(String disease, char gender, int age, float height, int weight, float PA) {
        log.info("calcRDA");
        float EER = 0;

        if (gender == '남') {
            EER = 622f - 9.53f * age + PA * (15.91f * weight + 536.6f * height);
        } else if (gender == '여') {
            EER = 354f - 6.91f * age + PA * (9.36f * weight + 726f * height);
        }

        return (int) EER;
    }

    // 각 질병유무에 따른 영양소 요구량을 계산 -> 하루치? 한끼인지?
    public Map<String, Integer> getNutrientRequirements(List<String> diseases, int caloricNeeds) {
        log.info("getNutrientRequirements");

        // 질병에 대한 영양소 요구량 저장
        Map<String, Map<String, Integer>> map = new HashMap<>();

        // 총 요구량을 저장할 맵 초기화 // 각 질병의 영양소 요구량 설정
        Map<String, Integer> tmpMap = new HashMap<>();
        tmpMap.put("carbs", 0);
        tmpMap.put("protein", 0);
        tmpMap.put("fat", 0);
        tmpMap.put("sodium", 0);
        tmpMap.put("omega-3", 500); // 하루 250-500mg
        map.put("치매", tmpMap);

        tmpMap = new HashMap<>();
        tmpMap.put("carbs", 220); // 한끼 45-75g
        tmpMap.put("protein", 90);// 한끼 기준 15-30g
        tmpMap.put("fat", 0);
        tmpMap.put("sodium", 0);
        tmpMap.put("omega-3", 0);
        map.put("당뇨", tmpMap);

        tmpMap = new HashMap<>();
        tmpMap.put("carbs", 0);
        tmpMap.put("protein", 0);
        tmpMap.put("fat", 60); // 한끼 10-20g
        tmpMap.put("sodium", 1500); // 1500mg
        tmpMap.put("omega-3", 0);
        map.put("고혈압", tmpMap);

        tmpMap = new HashMap<>();
        tmpMap.put("carbs", 0);
        tmpMap.put("protein", 0);
        tmpMap.put("fat", 30); // 한끼 기준 약 5-10g
        tmpMap.put("sodium", 0);
        tmpMap.put("omega-3", 500); // 하루 250-500mg
        map.put("고지혈증", tmpMap);

        // 요구량 계산 한끼 기준
        for (String disease : diseases) {
            if (map.containsKey(disease)) {
                Map<String, Integer> requirements = map.get(disease);

                // 탄수화물 요구량 계산
                tmpMap.put("carbs", tmpMap.get("carbs") + (int) ((caloricNeeds * 0.55) /3 / 4)); // 1g 탄수화물 = 4kcal

                // 나트륨 요구량 계산
                tmpMap.put("sodium", tmpMap.get("sodium") + requirements.get("sodium")/ 3);

                // 단백질 요구량 계산
                tmpMap.put("protein", tmpMap.get("protein") + requirements.get("protein") / 3);
                // 지방 요구량 계산
                tmpMap.put("fat", tmpMap.get("fat") + (int) ((caloricNeeds * 0.3/ 3) / 9)); // 1g 지방 = 9kcal

                // 오메가-3 요구량 계산
                tmpMap.put("omega-3", tmpMap.get("omega-3") + requirements.get("omega-3") / 3);
            }
        }

        return tmpMap;
    }

	@Override
	public Map<String, Map<String, Integer>> getNutrientRequirements(String disease) {
		// TODO Auto-generated method stub
		return null;
	}
}
