package com.dementia.memoryTable.domain;

import com.dementia.memoryTable.domain.naverAndGoogle.OAuthVO;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Data;

@Entity // 데이터베이스 테이블과 매핑된 객체
@Table(name="USER_HEALTH_FORM")
@Data
public class HealthVO{

	@Id
//	@GeneratedValue(strategy = GenerationType.SEQUENCE,
//	    generator = "USER_HEALTH_SEQ_GENERATOR")
//		@SequenceGenerator(
//		name = "USER_HEALTH_SEQ_GENERATOR",
//		sequenceName = "USER_HEALTH_SEQ",
//		initialValue = 1,
//		allocationSize = 1)
	@Column(name = "ID", nullable = false)
	private String id;

	@Column(name = "GENDER" , nullable = false, length =1)
	private char gender;

	@Column(name = "AGE")
	private int age;

	@Column(name = "WEIGHT")
	private int weight;

	@Column(name = "HEIGHT")
	private float height;

	@Column(name = "DISEASE")
	private String disease;

	@Column(name = "ACTIVITY")
	private float activity;

	@Column(name = "NAME")
	private String name;

	// 11.1 추가 외래키를 나타내기 위한 필드
	@Column(name = "MEMBER_ID")
	private String memberId;

	@Column(name = "OAUTH_ID")
	private String oauthId;

	// 외래키 설정 Entity 'com.dementia.memoryTable.domain.MemberVO' has no identifier (every '@Entity' class must declare or inherit at least one '@Id' or '@EmbeddedId' property)
//	@ManyToOne
//	@JoinColumn(name="ID", insertable = false, updatable = false)
//	private MemberVO member;
//
//	@ManyToOne
//	@JoinColumn(name="ID", insertable = false, updatable = false)
//	private OAuthVO oauth;



}
