package com.dementia.memoryTable.service;

import java.util.List;
import java.util.Map;

public interface HealthDiagnosticService {

	/**
	  일일 영양권장량(RDA) 계산 :  질병별 필요 권장량 확인하기 (65세 기준)

	  weight(체중) : kg,
	  height(신장) : m
	  EER(에너지 요구량 추정치(ESTIMATED ENERGY REQUIREMENT (EER))) : kcal


	 * @param disease 질병 : 고혈압, 당뇨, 고지혈증, 비만
	 * @param gender 성별 : 남/녀
	 * @param age  나이 : 30
	 * @param height 신장 : 1.6m
	 * @param weight 체중 : 60kg
	 * @param PA 활동성 : 성별, 나이, 신장, 체중, PA(Physical Activity:신체활동량)
			  PA(남성) = 1.0 (sedentary), 1.11 (low active), 1.25 (active), or 1.48 (very active).
			  PA(남성) : 1.1(저활동적), 1.48(매우 활동적)
			  PA(여성) = 1.0 (sedentary), 1.12 (low active), 1.27 (active), or 1.45 (very active).
			  PA(여성) : 1.2(저활동적), 1.45(매우 활동적)

	 * @return EER  : 에너지 추정량(kcal) : ESTIMATED ENERGY REQUIREMENT (EER) EQUATION
	 */
	int calculateRDA (String disease, char gender, int age, float height, int weight, float PA);

	Map<String, Map<String, Integer>> getNutrientRequirements(String disease);

	Map<String, Integer> getNutrientRequirements(List<String> diseases, int caloricNeeds);


}
