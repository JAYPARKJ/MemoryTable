package com.dementia.memoryTable.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="DISEASE_HARMFUL_FOODS")
@Data
public class DiseaseVO {

	@Id
	@Column(name="DISEASE")
	private String disease;

	@Column(name="HARMFUL_FOOD")
	private String harmfulFood;


}