package com.dementia.memoryTable.domain;


import java.util.regex.Pattern;

import lombok.Data;

@Data
public class Ingredient {
    private String name; // 재료 이름
    private String quantity; // 양

    // 생성자 추가
    public Ingredient(String name, String quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    public static String formatIngredients(String str)
    {
    	// String str = "깐 녹두 300g돼지고기다짐육 600g숙주나물 1봉지도라지나물 120g시금치나물 120g고사리나물 120g다진마늘 2큰술다진생강 1작은술청주 2큰술밀가루 100g천연조미료/황태육수 농도에맞게 식용유 ";
    	//String[] strs = str.trim().split("\\s");
    	String strs[] = str.replace("T", "Ts").replace("Tss", "Ts").split("\\s");

    	// 숫자와 함께 나올 수 있는 단위들
        String[] units = { "개", "장", "Ts", "티스푼", "스푼", "톨", "컵", "약간", "kg", "마리", "큰술", "ts", "g", "알",
        					"공기", "숟갈", "팩", "oz", "포기", "수저", "대", "봉지", "줌", "꼬집", "모양" }; // 10.31 추가

        String resultStr = strs[0];

        // 공백으로 나눈 strs[] 배열을 순회하며 단어 확인
        for(int i =0; i<strs.length; i++) {

        	for(String uStr : units) {

        		// 단위 포함 여부 확인
        		if(strs[i].contains(uStr)) {

        			int idx = strs[i].indexOf(uStr);

	        		if(strs[i].contains("약간")) {
	        			// 11.05 if문 추가
	        			if (idx + 2 <= strs[i].length()) {
	        				String temp = strs[i].substring(0, idx+2);
		        			String nextStr = strs[i].substring(strs[i].indexOf("약간") + 2);
		        			resultStr += " " + temp + "*" + nextStr;
	        			}

	        		}
	        		else {
	        			// 단위 바로 앞의 문자가 숫자인지 확인
	        			String temp = strs[i].charAt(idx-1) + "";
	        			boolean isDigit = Pattern.matches("\\d{1,}", temp);

	        			if(isDigit) {
	        				int endIdx = uStr.length();
	        				resultStr += " " + strs[i].substring(0, idx + endIdx) + "*" + strs[i].substring(idx + endIdx);
	        			}
        			}
        		}
        	}
        }
		return resultStr;
	}
}