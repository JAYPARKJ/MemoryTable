package com.dementia.memoryTable.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dementia.memoryTable.domain.DietVO;
import com.dementia.memoryTable.domain.HealthVO;
import com.dementia.memoryTable.repository.DietDAO;
import com.dementia.memoryTable.repository.HealthDAO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class HealthFilterService {

	@Autowired
	private DietDAO dietDAO; // DietDAO 주입

	@Autowired
	private HealthDiagnosticService healthDiagnosticService;

	@Autowired
	private HealthDAO healthDAO;

	@Transactional(readOnly = true)
	public List<DietVO> searchRecipes(String query) {
		// 사용자가 입력한 쿼리를 기준으로 레시피 검색
		return dietDAO.findByFoodNameContainingOrIngredientContaining(query, query);
	}

	// 11.04 개인 건강정보 조회(id)
	@Transactional(readOnly = true)
	public HealthVO getUserHealthInfo(String id) {
		// id로 검색
		return healthDAO.findById(id).orElse(null);
	}

	public void calculateAndProvideAdvice(String id) {
		HealthVO healthInfo = getUserHealthInfo(id);
		if (healthInfo != null) {
			// RDA 계산 및 영양소 요구량 처리 로직
			String disease = healthInfo.getDisease();
			char gender = healthInfo.getGender();
			int age = healthInfo.getAge();
			float height = healthInfo.getHeight(); // m 단위로 변환 필요
			int weight = healthInfo.getWeight();
			float PA = healthInfo.getActivity(); // 활동성 값 조정 필요

			// RDA 계산
			int EER = healthDiagnosticService.calculateRDA(disease, gender, age, height, weight, PA);

			// 영양소 요구량 계산
			Map<String, Integer> nutrientRequirements = healthDiagnosticService
					.getNutrientRequirements(List.of(disease), EER);

		} else {
			System.out.println("사용자 정보를 찾을 수 없습니다.");
		}
		// 영양소 요구량 부분 메서드 x , 질병별 유해음식 필터링만 구현

	}

	// 11.01 추가
	@Transactional
	public HealthVO saveHealthForm(HealthVO healthVO) {

		// jpa 방식 사용 저장
		return healthDAO.save(healthVO);
		// return "/member/privateHealthInput";

		// jdbc 방식
//    		 String sql = "INSERT INTO USER_HEALTH_FORM (ID, GENDER, AGE, WEIGHT, HEIGHT, DISEASE, ACTIVITY, NAME, MEMBER_ID, OAUTH_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
//
//    	        try (Connection conn = DatabaseConfig.getConnection();
//    	             PreparedStatement pstmt = conn.prepareStatement(sql)) {
//
//    	            pstmt.setInt(1, healthVO.getId());
//    	            pstmt.setString(2, String.valueOf(healthVO.getGender()));
//    	            pstmt.setInt(3, healthVO.getAge());
//    	            pstmt.setInt(4, healthVO.getWeight());
//    	            pstmt.setInt(5, healthVO.getHeight());
//    	            pstmt.setString(6, healthVO.getDisease());
//    	            pstmt.setInt(7, healthVO.getActivity());
//    	            pstmt.setString(8, healthVO.getName());
//    	            pstmt.setString(9, healthVO.getMemberId());
//    	            pstmt.setString(10, healthVO.getOauthId());
//
//    	            pstmt.executeUpdate();
//    	        } catch (SQLException e) {
//    	            e.printStackTrace();
//    	        }

		// return this.saveHealthForm(healthVO); stackoverflow
	}
}
