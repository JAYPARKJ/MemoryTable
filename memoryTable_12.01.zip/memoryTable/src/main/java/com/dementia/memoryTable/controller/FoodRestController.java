package com.dementia.memoryTable.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class FoodRestController {

	@PostMapping("/deleteImages")
	public ResponseEntity<Boolean> deleteImages(@RequestBody String ids){

		log.info("deleteImages");
		log.info("ids : " + ids);

		boolean result = false;

		ObjectMapper om = new ObjectMapper();

		try {

			@SuppressWarnings("unchecked")
			Map<String, List<String>> obj = om.readValue(ids, Map.class); // JSON => Map 변환

			obj.get("ids").forEach(x -> { log.info("값 : " + x); } );

			// TODO : 실제 DB 처리(삭제)
			// 삭제가 제대로 처리되면 true 그렇지 않으면 false
			result = true;

		} catch (JsonMappingException e) {
			log.error("json 해석 오류-1");
			e.printStackTrace();
			result = false;
		} catch (JsonProcessingException e) {
			log.error("json 해석 오류-2");
			e.printStackTrace();
			result = false;
		}

		return new ResponseEntity<>(result, HttpStatus.OK);
	}
}