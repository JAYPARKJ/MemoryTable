package com.dementia.memoryTable.controller;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.dementia.memoryTable.domain.Users;
import com.dementia.memoryTable.service.DietService;
import com.dementia.memoryTable.service.EmailService;
import com.dementia.memoryTable.service.HealthDiagnosticService;
import com.dementia.memoryTable.service.HealthFilterService;
import com.dementia.memoryTable.service.MemberService;
import com.dementia.memoryTable.service.RandomDietImgService;
import com.dementia.memoryTable.domain.CustomUser;
import com.dementia.memoryTable.domain.DietVO;
import com.dementia.memoryTable.domain.HealthVO;
import com.dementia.memoryTable.domain.Ingredient;
import com.dementia.memoryTable.domain.MemberDTO;
import com.dementia.memoryTable.domain.MemberUpdateDTO;
import com.dementia.memoryTable.domain.MemberVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class AuthController {
	@Value("${image.repo.location}")
	String filePath;

	@Autowired
	MemberService memberService;

	@Autowired
	DietService dietService;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	@Autowired // 10.17
	RandomDietImgService randomDietImgService;

	// 09.27 간편로그인
	@GetMapping({"/oauth2/authorization/naver",
				 "/oauth2/authorization/google",
				 "/home", "/"})
	public String welcome(@RequestParam(value = "disease", defaultValue = "")String disease, Model model, HttpSession session) {
		log.info("oauth2/home");

		// 캐러셀 슬라이드 이미지 준비 (랜덤 5개 선정) - 인자 생성
		List<Map<String, Object>> imgs =  randomDietImgService.randomDietImg();
		model.addAttribute("mainImgs", imgs);

		List<DietVO> newList = dietService.getTop8NewsDiets();
		log.info("New List: " + newList);
		model.addAttribute("news", newList);

		log.info("disease : " + disease);

		// 선택된 질병에 맞는 추천 레시피 조회 (8개 레시피 가져오기)
		if (disease.equals("") == false) {
			log.info("recomms 인장 생성 : ");
			List<Integer> recommIdList = dietService.getRecomm(disease, 8);

			List<DietVO> recommList = dietService.getDietsByIds(recommIdList);
		    log.info("Recomm List : " + recommList);
		    model.addAttribute("recomms", recommList);
		}

		return "home";
	} //

	// demo 10.24 임시 데모 추가
	@GetMapping("/demo")
	@ResponseBody
	public String demo() {
		log.info("demo");
		return "demo";
	}

	// 관리자용 주소
	@GetMapping("/admin/home")
	public String securedAdminHome(ModelMap model) {

		log.info("/admin/home");

		// Security pricipal 객체 (사용자 인증/인가 정보 객체)
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		CustomUser user = null;

		if (principal instanceof CustomUser) {
			user = ((CustomUser) principal);
		}

		log.info("user : " + user);

		String name = user.getUsername();
		model.addAttribute("username", name);
		model.addAttribute("message", "관리자 페이지에 들어오셨습니다.");

		return "/home";
	}

	// (일반)사용자용 주소
	@GetMapping("/secured/home")
	public String securedHome(ModelMap model) {

		log.info("/secured/home");

		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		CustomUser user = null;

		if (principal instanceof CustomUser) {
			user = ((CustomUser) principal);
		}

		log.info("user : " + user);

		String name = user.getUsername();
		model.addAttribute("username", name);
		model.addAttribute("message", "일반 사용자 페이지에 들어오셨습니다.");

		return "/secured/home";
	}

	@GetMapping("/AdminOrUser")
	public String AdminOrUser(Model model) {
		log.info("회원 or 관리자");
		return "/AdminOrUser";
	}

	@GetMapping("/join_user")
	public String join_user(Model model) {
		log.info("회원 가입폼");
		model.addAttribute("memberDTO", new MemberVO());
		return "join_user";
	}

	@GetMapping("/join_admin")
	public String join_admin(Model model) {
		log.info("관리자 가입폼");
		model.addAttribute("memberDTO", new MemberVO());
		return "join_admin";
	}


	// 10.11 아이디찾기
	@GetMapping("/findId")
	public String findId(Model model) {
		log.info("아이디찾기");
		return "/find/findId";
	}

	@GetMapping("/foundId")
	public String foundId(@RequestParam(value="id", defaultValue = "") String id, Model model) {
		log.info("id : " + id);
		id = id.equals("null") ? "없음" : id;

		model.addAttribute("id", id);

		return "/find/foundId";
	}

	// 10.14 비밀번호찾기
	@GetMapping("/findPw")
	public String findPw(Model model) {
		log.info("임시비밀번호");
		return "/find/findPw";
	}

	// 로그인 폼
	@GetMapping("/loginForm")
	public String loginForm() {

		log.info("loginForm");

		// 로그인/로그아웃 (인증) 처리
		// loginProcessingUrl("/login") 추가
		// : Spring Security 6.x의 404 에러 간헐 발생에 따른 버그 패치 조치
	    // 이슈(issue) 참고) https://github.com/spring-projects/spring-security/issues/12635

     	// 버그 패치) Spring Security Login Page Redirect(페이지 이동 문제)에 따른 조치
    	// 버그 리포트(bug report) : 일반적으로 최초로 로그인할 경우 발생
    	// 버그 증상) 로그인 성공시에도 불구하고 home로 이동되지 않고 loginForm 페이지에 머물러 있음
    	// 버그 구체적인 패치 대응) 로그인 상태를 Authentication 정보를 통해서 수동 점검하여
    	// forward 페이지를 인증/미인증별로 선택적으로 설정
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String path="";

		// 로그인 인증 안되었을 경우 인증정보(Authentication) dump
    	//
    	// AnonymousAuthenticationToken [Principal=anonymousUser, Credentials=[PROTECTED],
    	// Authenticated=true, Details=WebAuthenticationDetails [RemoteIpAddress=0:0:0:0:0:0:0:1,
    	// SessionId=C4B68A207EF642308F11925E998570FC], Granted Authorities=[ROLE_ANONYMOUS]
		log.info("login시 인증정보 : " + auth);
		/*
		if (auth.getPrincipal() == null || auth.getPrincipal().toString().equals("anonymousUser")) { // 로그인 인증이 안되었을 경우

			log.info("로그인 인증 안됨");
			path = "loginForm";
		} else {

			log.info("로그인 인증됨");
			path = "home";
		} //
		*/
		return "loginForm";
		// return path;
	}

	// 로그아웃 처리
	@GetMapping("/logoutProc")
	public String logout(ModelMap model, HttpServletRequest request, HttpServletResponse response) {

		log.info("logout");

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		log.info("auth : " + auth);

		// logout !
		if (auth != null) {
			new SecurityContextLogoutHandler().logout(request, response, auth);
		}

		return "logout";
	} //

	// 로그인(인증) 에러
	// 10.24 로그인 실패 팝업
	@GetMapping("/loginError")
	public String loginError(HttpSession session, RedirectAttributes ra, Model model) {

		// Spring CustomProvider 인증(Authentication) 에러 메시지 처리
		Object secuSess = session.getAttribute("SPRING_SECURITY_LAST_EXCEPTION");

		log.info("#### 인증 오류 메시지 : " + secuSess);

		ra.addFlashAttribute("error", "true");
		ra.addFlashAttribute("msg", secuSess);

		String msg = ""; // 저장 성공/실패 메시지
		String success = ""; // 가입 성공 여부
		String path = ""; // 처리 후 이동 페이지

		msg = "입력된 회원정보가 없습니다.";
		success = "error";
		path = "/loginForm";

		model.addAttribute("msg", msg);
		model.addAttribute("success", success);

		// return "redirect:/loginForm";
		return path;
	} //

	// id 존재 여부 점검
	@RequestMapping("/login/idCheck")
	@ResponseBody
	public String idCheck(@RequestParam("username") String username, Model model) {

		log.info("username : ", username);

		boolean flag = memberService.hasMemberByFld("ID", username);
		log.info("flag : ", flag);

		return flag + "";
	} //

	// access denied(403) : 인가(Authorization) 에러 : 접근 권한 부족
	@GetMapping("/403")
	public String error403() {

		return "/error/403";
	}

} //