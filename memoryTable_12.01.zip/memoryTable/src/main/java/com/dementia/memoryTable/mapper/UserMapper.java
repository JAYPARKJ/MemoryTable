package com.dementia.memoryTable.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.data.repository.query.Param;

@Mapper
public interface UserMapper {

	void updateResetPassword(@Param("id") String id, @Param("pw") String pw);
}
