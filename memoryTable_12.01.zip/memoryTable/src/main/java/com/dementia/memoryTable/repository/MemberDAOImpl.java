package com.dementia.memoryTable.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dementia.memoryTable.domain.MemberVO;

@Repository
public class MemberDAOImpl implements MemberDAO {

	private static final Logger log = LoggerFactory.getLogger(MemberDAOImpl.class);

	@Autowired
	SqlSession sqlSession; // MyBatis Session 객체

	@Override
	public MemberVO selectMemberById(String id) {
		return sqlSession.selectOne("mapper.MemberMapper.selectMemberById", id);
	}

	@Override
	public List<MemberVO> selectMembersByPaging(int page, int limit) {
		HashMap<String, Object> hashMap = new HashMap<>();
		hashMap.put("page", page);
		hashMap.put("limit", limit);

		log.info("page : "+ hashMap.get("page"));
		log.info("limit : "+ hashMap.get("limit"));

		return sqlSession.selectList("mapper.MemberMapper.selectMembersByPaging", hashMap);
	}

	@Override
	public List<MemberVO> selectAllMembers() {
		return sqlSession.selectList("mapper.MemberMapper.selectAllMembers");
	}

	@Override
	public boolean insertMember(MemberVO memberVO) {
		boolean returnValue = false;

		try {

			sqlSession.insert("mapper.MemberMapper.insertMember", memberVO);
			returnValue = true;

		} catch (Exception e) {
			log.error("insertMember 오류 : " + e);
			e.printStackTrace();
			returnValue = false;
		}

		return returnValue;
	}

	@Override
	public boolean updateMember(MemberVO memberVO) {
		boolean returnValue = false;

		try {
			// 기존 회원정보 존재 여부 점검
			int result
				= this.selectMemberById(memberVO.getId()) != null ? 1 : 0;

			if (result == 0) { // 수정할 회원정보가 없음(부재시)
				// log.error("회원정보가 존재하지 않습니다.");
				// returnValue = false;
				throw new Exception("회원정보가 존재하지 않습니다.");
			}

			sqlSession.update("mapper.MemberMapper.updateMember", memberVO);

			// else {
			//	returnValue = true;
			// }

			returnValue = true;

		} catch (Exception e) {
			log.error("updateMember 오류 : {}", e);
			e.printStackTrace();
			returnValue = false;
		}

		return returnValue;
	}

	@Override
	public boolean hasMemberByFld(String fld, String val) {
		Map<String, String> map = new HashMap<>();
		map.put("fld", fld);
		map.put("val", val);

		return (int)sqlSession.selectOne("mapper.MemberMapper.hasMemberByFld", map) == 1 ? true : false;
	}

	@Override
	public boolean hasMemberForUpdate(String id, String fld, String val) {
		Map<String, String> map = new HashMap<>();
		map.put("id", id);
		map.put("fld", fld);
		map.put("val", val);

		return (int)sqlSession.selectOne("mapper.MemberMapper.hasMemberForUpdate", map) == 1 ? true : false;
	}

	@Override
	public List<Map<String, Object>> selectMembersBySearchingAndPaging(String searchKey, String searchWord, int page,
			int limit, String isLikeOrEquals, String ordering) {
		Map<String, Object> map = new HashMap<>();
		map.put("searchKey", searchKey);
		map.put("searchWord", searchWord);
		map.put("page", page);
		map.put("limit", limit);
		map.put("isLikeOrEquals", isLikeOrEquals);
		map.put("ordering", ordering);

		log.info("인자 출력 : ");
		map.entrySet().forEach(x-> { log.info(x +""); });

		return sqlSession.selectList("mapper.MemberMapper.selectMembersBySearchingAndPaging", map);
	}

	@Override
	public Map<String, Object> selectMemberByFld(String fld, Object val) {
		Map<String, Object> map = new HashMap<>();
		map.put("fld", fld);
		map.put("val", val);

		return sqlSession.selectOne("mapper.MemberMapper.selectMemberByFld", map);
	}

	@Override
	public boolean insertRole(String id, String role) {
		boolean returnValue = false;

		try {

			Map<String, String> map = new HashMap<>();
			map.put("id", id);
			map.put("role", role);

			sqlSession.insert("mapper.MemberMapper.insertRole", map);
			returnValue = true;

		} catch (Exception e) {
			log.error("insertRole 오류 : " + e);
			e.printStackTrace();
			returnValue = false;
		}

		return returnValue;
	}

	@Override
	public boolean deleteRoles(String id) {
		boolean returnValue = false;

		try {

			sqlSession.delete("mapper.MemberMapper.deleteRoles", id);
			returnValue = true;

		} catch (Exception e) {
			log.error("deleteRoles 오류 : " + e);
			e.printStackTrace();
			returnValue = false;
		}

		return returnValue;
	}

	@Override
	public boolean deleteMemberById(String id) {
		boolean returnValue = false;

		try {

			sqlSession.delete("mapper.MemberMapper.deleteMemberById", id);
			returnValue = true;

		} catch (Exception e) {
			log.error("deleteMemberById 오류 : " + e);
			e.printStackTrace();
			returnValue = false;
		}

		return returnValue;
	}

	@Override
	public int selectCountAll() {
		return sqlSession.selectOne("mapper.MemberMapper.selectCountAll");
	}

	@Override
	public List<String> selectRolesById(String id) {
		return sqlSession.selectList("mapper.MemberMapper.selectRolesById", id);
	}

	@Override
	public void deleteRoleById(String id, String role) {
		Map<String, String> map = new HashMap<>();
		map.put("id",  id);
		map.put("role", role);

		sqlSession.delete("mapper.MemberMapper.deleteRoleById", map);
	}

	@Override
	public void changeEnabled(String id, int enabled) {
		Map<String, Object> map = new HashMap<>();
		map.put("id", id);
		map.put("enabled", enabled);

		log.info("상태 정보 : {}", enabled);

		sqlSession.update("mapper.MemberMapper.changeEnabled", map);
	}

	@Override
	public int selectCountBySearching(String searchKey, String searchWord) {
		Map<String, Object> map = new HashMap<>();
		map.put("searchKey", searchKey);
		map.put("searchWord", searchWord);

		return (int)sqlSession.selectOne("mapper.MemberMapper.selectCountBySearching", map);
	}

	// 10.11 아이디찾기
	@Override
	public String findId(String name, String email) {
		Map<String, Object> map = new HashMap<>();
		map.put("name", name);
		map.put("email", email);

		return sqlSession.selectOne("mapper.MemberMapper.findId", map);
	}

	// 10.16 임시비밀번호
	@Override
	public int updatePwd(MemberVO memberVO) {
		return sqlSession.selectOne("mapper.MemberMapper.updatePwd", memberVO);
	}

}
