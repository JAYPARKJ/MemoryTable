package com.dementia.memoryTable.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.dementia.memoryTable.domain.DietVO;
// CRUD + 페이징 형태로 치환
public interface DietDAO extends CrudRepository<DietVO, Integer>, PagingAndSortingRepository<DietVO, Integer>
{

	  // 페이징 처리된 모든 레시피 가져오기
	  @Query("SELECT d FROM DietVO d")
	  Page<DietVO> findAll(Pageable pageable);

	  // 조회수 기준 상위 4개의 인기 레시피 가져오기 <- 전체 레시피에서 정렬
	  @Query("SELECT d FROM DietVO d ORDER BY d.id Asc")
	  List<DietVO> findTop4ByOrderByIdAsc(Pageable pageable);

	  // 최신 레시피 상위 8개 가져오기
	  @Query("SELECT d FROM DietVO d ORDER BY d.id DESC")
	  List<DietVO> findTop8ByOrderByIdDesc(Pageable pageable);

	  List<DietVO> findByFoodNameContainingOrIngredientContaining(String query, String query2);

	  // 레시피 이름이나 재료에 키워드가 포함된 레시피 검색

	  List<DietVO> findByFoodNameContaining(String foodName);

	  List<DietVO> findByFoodNameEndingWith(String foodName);

	 // List<String>  getIngredients();
}
