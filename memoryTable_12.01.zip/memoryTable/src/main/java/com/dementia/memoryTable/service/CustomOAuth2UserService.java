package com.dementia.memoryTable.service;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.dementia.memoryTable.repository.OAuthUserJpaDAO;
import com.dementia.memoryTable.repository.OAuthUserMyBatisDAO;
import com.dementia.memoryTable.repository.UserRepository;
import com.dementia.memoryTable.domain.naverAndGoogle.OAuthVO;
import com.dementia.memoryTable.domain.naverAndGoogle.OAuthAttributes;
import com.dementia.memoryTable.domain.naverAndGoogle.SessionOAuth;

import jakarta.servlet.http.HttpSession;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Getter
@Setter
@Service
@Slf4j
public class CustomOAuth2UserService implements OAuth2UserService<OAuth2UserRequest, OAuth2User> {

	@Autowired
	private UserRepository userRepository;
	private final HttpSession httpSession;
	
	@Autowired
	OAuthUserMyBatisDAO oAuthUserMyBatisDAO;
	// OAuthUserJpaDAO oAuthUserJpaDAO;
	
	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public OAuth2User loadUser (OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		
		log.info("loadUser : ");
		
		OAuth2UserService delegate = new DefaultOAuth2UserService();
		OAuth2User oAuth2User = delegate.loadUser(userRequest);
		
		String registrationId = userRequest.getClientRegistration().getRegistrationId();
		String userNameAttributeName = userRequest.getClientRegistration().getProviderDetails()
										.getUserInfoEndpoint().getUserNameAttributeName();
		
		OAuthAttributes attributes = OAuthAttributes.of(registrationId, userNameAttributeName, oAuth2User.getAttributes());
		
		// OAuthVO oAuth = saveOrUpdate(attributes);
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// 옛날식 jpa
		
//		OAuthVO oAuthVO = userRepository.findByEmail(attributes.getEmail())
//										.map(entity -> entity.update(attributes.getName(),
//												attributes.getMobile(),
//												attributes.getAuthVendor())) // attributes.getAuthVendor()추가
//										.orElse(attributes.toEntity());
		
		// OAuthVO oAuthVO = oAuthUserMyBatisDAO.selectOAuthVO(attributes.getEmail());
		// log.info("oAuthVO(저장전): {}", oAuthVO);
		
		OAuthVO oAuthVOExisted = oAuthUserMyBatisDAO.selectOAuthVO(attributes.getEmail());
		log.info("oAuthVO(가입여부): {}", oAuthVOExisted);
		OAuthVO oAuthVO = null;
		
		if (oAuthVOExisted == null) {
			log.info("저장");
			
			oAuthVOExisted = userRepository.findByEmail(attributes.getEmail())
										.map(entity -> entity.update(attributes.getName(),
												attributes.getMobile(),
												attributes.getAuthVendor())) // attributes.getAuthVendor()추가
										.orElse(attributes.toEntity());
			
			// 09.27
			String tempMobile = attributes.getMobile() == null ? "없음" : attributes.getMobile();
			oAuthVOExisted.setMobile(tempMobile);
			
			oAuthUserMyBatisDAO.insertOAuthVO(oAuthVOExisted);
		} else {
			log.info("수정");
			oAuthUserMyBatisDAO.updateOAuthVO(oAuthVOExisted);
		}
		
		// oAuthUserJpaDAO.insertOAuthVO(oAuthVO);
		// oAuthVO = oAuthUserJpaDAO.selectOAuthVO(oAuthVO.getEmail());
		
		oAuthVO = oAuthUserMyBatisDAO.selectOAuthVO(oAuthVOExisted.getEmail());
		log.info("oAuthVO(저장후): {}", oAuthVO);
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		oAuthVO.setAuthVendor(attributes.getAuthVendor());
		
		log.info("CustomOAuth2UserService loadUser oAuth : " + oAuthVO);
		
		// 인증 세션 생성
		httpSession.setAttribute("oAuth", new SessionOAuth(oAuthVO));
		
		return new DefaultOAuth2User (
			Collections.singleton(new SimpleGrantedAuthority(oAuthVO.getRoleKey())),
			attributes.getAttributes(),
			attributes.getNameAttributeKey());
	}
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public OAuthVO saveOrUpdate(OAuthAttributes attributes) {
		
		log.info("회원정보 저장/수정 : " + attributes);
		
		OAuthVO oAuthVO = userRepository.findByEmail(attributes.getEmail())
				.map(entity -> entity.update(attributes.getName(),
						attributes.getMobile(),
						attributes.getAuthVendor())) // attributes.getAuthVendor()추가
				.orElse(attributes.toEntity());
		
		log.info("oAuthVO(저장): {}", oAuthVO);
		
		OAuthVO result = null;
		
		try {
			log.info("저장전");
			result = userRepository.save(oAuthVO);
			// userRepository.insertUser(oAuthVO);
			log.info("저장후: {}", result);
		} catch (Exception e) {
			log.error("oAuthVO 회원정보 저장 오류: " + e);
		}
		
		log.info("oAuthVO 회원정보 끝");
		
		return result;
		 // return userRepository.save(oAuthVO);
	}
}
