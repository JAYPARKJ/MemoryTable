package com.dementia.memoryTable.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.dementia.memoryTable.domain.naverAndGoogle.OAuthVO;

import java.util.Optional;

// public interface UserRepository extends JpaRepository<OAuthVO, Long> {
public interface UserRepository extends CrudRepository<OAuthVO, Long> {
	
    Optional<OAuthVO> findByEmail(String email);
    
    // OAuthVO save(OAuthVO oAuthVO);
    @Modifying
    @Query(value = "INSERT INTO USER_TBL VALUES ("
	    		+ "    USER_SEQ.NEXTVAL,"
	    		+ "	   :#{#oAuthVO.name}, :#{#oAuthVO.email},"
	    		+ "    :#{#oAuthVO.mobile}, :#{#oAuthVO.role},"
	    		+ "    sysdate, sysdate, :#{#oAuthVO.authVendor}"
	    		+ ")", nativeQuery=true)
    void insertUser(@Param("oAuthVO") OAuthVO oAuthVO);
}
