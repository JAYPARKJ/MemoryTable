package com.dementia.memoryTable.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.dementia.memoryTable.domain.naverAndGoogle.OAuthVO;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
@Transactional
public class OAuthUserJpaDAO {
   
    @PersistenceContext
    private EntityManager entityManager;
   
    @Autowired
    @Qualifier(value = "transactionManager")
    // private JpaTransactionManager transactionManager;
    PlatformTransactionManager transactionManager;
   
    public void insertOAuthVO(OAuthVO oAuthVO) {
    	
    	log.info("insertOAuthVO");
    	
        DefaultTransactionDefinition def = new DefaultTransactionDefinition();
        def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
     
        TransactionStatus status = transactionManager.getTransaction(def);
       
        try {
           
            entityManager.merge(oAuthVO);
            transactionManager.commit(status);
           
        } catch (Exception e) {
           
            log.info("insertOAuthVO error : {}", e);
            transactionManager.rollback(status); 
            e.getStackTrace();
        } //
       
    } //
    
    public OAuthVO selectOAuthVO(String email) {

	   return (OAuthVO) entityManager.createNativeQuery("SELECT * FROM user_tbl WHERE EMAIL = ?",
	                                             OAuthVO.class).setParameter(1, email).getSingleResult();
	} //
   
}
