package com.dementia.memoryTable.controller;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.dementia.memoryTable.domain.CustomUser;
import com.dementia.memoryTable.domain.HealthVO;
import com.dementia.memoryTable.domain.MemberVO;
import com.dementia.memoryTable.service.DietService;
import com.dementia.memoryTable.service.HealthFilterService;
import com.dementia.memoryTable.service.MemberService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class PrivateHealthInputController {

	@Value("${image.repo.location}")
	String filePath;

	@Autowired
	MemberService memberService;

	@Autowired
	DietService dietService;

	@Autowired
	HealthFilterService healthFilterService;

	@GetMapping("/member/privateHealthInput") // 건강정보폼 입력 형식
	public String privateHealthInput(Model model) {

		// Spring Security Principal(Session) 조회
		Object principal = SecurityContextHolder.getContext()
												.getAuthentication()
												.getPrincipal();

		CustomUser customUser = (CustomUser)principal;
		log.info("principal : {}", principal);
		log.info("id : {}", customUser.getUsername()); // 로그인 아이디

		MemberVO memberVO = memberService.selectMemberById(customUser.getUsername());

		// 나이 계산 age
		// 자체 로그인 경우 : 생년월일 나이 계산
		// 구글 && 네이버 : 직접 입력
		//int age = 0;
		// 10.27일 수정

		int age = AgeCalculator(memberVO.getBirthday());
		log.info("Birthday: {}", memberVO.getBirthday());
		model.addAttribute("age", age);

		model.addAttribute("memberVO",memberVO);

		return "member_health/private_health_input";
	}

	// 건강정보폼 입력 처리 11.01
	@PostMapping("/member/privateHealthInputAction")
	public String privateHealthInputAction(Model model, @ModelAttribute HealthVO healthVO) {

		log.info("privateHealthInputAction : " + healthVO);
//		// Spring Security Principal(Session) 조회
//		Object principal = SecurityContextHolder.getContext()
//												.getAuthentication()
//												.getPrincipal();

//		CustomUser customUser = (CustomUser)principal;
//		log.info("principal : {}", principal);
//		log.info("id : {}", customUser.getUsername()); // 로그인 아이디

//		MemberVO memberVO = memberService.selectMemberById(customUser.getUsername());
//
//		model.addAttribute("memberVO",memberVO);
//
//
		// 나이 계산 age
		// 자체 로그인 경우 : 생년월일 나이 계산
		// 구글 && 네이버 : 직접 입력
		//int age = 0;
		// 10.27일 수정
//		int age = AgeCalculator(memberVO.getBirthday());
//		log.info("Birthday: {}", memberVO.getBirthday());
//		model.addAttribute("age", age);

		// 건강 정보 폼(healthVO) 저장 11.01
		HealthVO saveHealthVO = healthFilterService.saveHealthForm(healthVO);
		// model.addAttribute("saveHealthVO", saveHealthVO);  // model에 저장된 객체 추가

		return "redirect:/member/privateHealthInput";
	}

	private int AgeCalculator(Date birthDate) {

		if(birthDate ==  null) {


			return 0;
		}

		// Date를 LocalDate로 변환
		LocalDate birthDateLocal = birthDate.toInstant()
											.atZone(ZoneId.systemDefault())
											.toLocalDate();

		LocalDate currentDate  = LocalDate.now();
 		// System.out.println(localDateTime.format(dateTimeFormatter));


 		return Period.between(birthDateLocal, currentDate).getYears();
	}

}