package com.dementia.memoryTable.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dementia.memoryTable.domain.CustomUser;
import com.dementia.memoryTable.domain.DietVO;
import com.dementia.memoryTable.domain.Scrap;
import com.dementia.memoryTable.domain.naverAndGoogle.SessionOAuth;
import com.dementia.memoryTable.service.DietService;
import com.dementia.memoryTable.service.ScrapService;

import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class ScrapController {
    
    private final ScrapService scrapService;
    private final DietService dietService;

    @Autowired
    public ScrapController(ScrapService scrapService,DietService dietService) {
        this.scrapService = scrapService;
        this.dietService = dietService;
    }
    
    // 자체 로그인
    @GetMapping("/scrapList")
    public String getScrapList(Model model) {
    	
    	log.info("scrapList");
    	Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    	CustomUser user = null;

		if (principal instanceof CustomUser) {
			user = ((CustomUser) principal);
		}
		
    	String username = user.getUsername();
        List<Scrap> scrapList = scrapService.getScrapListByUsername(username);
        List<DietVO> dietList = new ArrayList<>();
        for (Scrap scrap : scrapList) {
        	dietList.add(dietService.getDietById(scrap.getFoodId()));
        }
        
        model.addAttribute("scrapList", scrapList);
        model.addAttribute("dietList", dietList);
        
        return "scrapList";  // scrapList.html 페이지로 데이터 전달
    }
 
    // 네이버,구글 로그인
    @GetMapping("/scrapListOAuth")
    public String getScrapListOAuth(Model model, HttpSession session) {
    	
    	// 11.27 수정
    	log.info("scrapListOAuth");
    	
    	SessionOAuth sessionOAuth = (SessionOAuth)session.getAttribute("oAuth");
    	// 11.27 String username = sessionOAuth.getEmail()+"_"+sessionOAuth.getAuthVendor();
    	//String username = sessionOAuth.getEmail();
    	 String username =  sessionOAuth.getEmail()+"_"+sessionOAuth.getAuthVendor();
    	log.info("username: " + username);
    	
        List<Scrap> scrapList = scrapService.getScrapListByUsername(username);
        List<DietVO> dietList = new ArrayList<>();
        for (Scrap scrap : scrapList) {
        	dietList.add(dietService.getDietById(scrap.getFoodId()));
        }
        
//      model.addAttribute("scrapList", scrapList);
        // 11.27 수정
        model.addAttribute("scrapListOAuth", scrapList);
        model.addAttribute("dietList", dietList);
        
        return "scrapListOAuth";  // scrapList.html 페이지로 데이터 전달 
    }

    @PostMapping("/registFoodId/{foodId}")
    @ResponseBody
    public ResponseEntity<Boolean> registerFoodId(@PathVariable("foodId") int foodId, HttpSession session) {
    	
    	log.info("registerFoodId:"+foodId);
    	
    	boolean result= false;
    	Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		CustomUser user = null; 
		String username = "";
		
		try {
			// 자체 로그인
			if (principal instanceof CustomUser) {
				user = ((CustomUser) principal);
			}
			
			log.info("user : " + user);
			username = user.getUsername();
			
		} catch(NullPointerException e) {
			// 네이버,구글로그인
			SessionOAuth sessionOAuth = (SessionOAuth)session.getAttribute("oAuth");
	    	username = sessionOAuth.getEmail()+"_"+sessionOAuth.getAuthVendor();
		}
        
        Optional<Scrap> scrap = scrapService.getScrapListByUsernameAndFoodId(username, foodId);
        
        if (scrap.isEmpty() == true) {
        	result = scrapService.saveScrap(username, foodId);
        } else {
        	result = scrapService.deleteScrap(username, foodId) == true ? false:true;
        }
        
        return new ResponseEntity<>(result,HttpStatus.OK);
    }
    			
    @GetMapping("/registFoodIds")
    @ResponseBody
    public ResponseEntity<Boolean> registerFoodIds(@RequestParam("IDS") String ids, HttpSession session) {
    	
    	log.info("registerFoodIds:"+ids);
    	boolean result= false;
   
    	Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		CustomUser user = null; 
		String username = "";
		
		try {
			// 자체 로그인
			if (principal instanceof CustomUser) {
				user = ((CustomUser) principal);
			}
			
			log.info("user : " + user);
			username = user.getUsername();
			
		} catch(NullPointerException e) {
			// 네이버,구글로그인
			SessionOAuth sessionOAuth = (SessionOAuth)session.getAttribute("oAuth");
	    	username = sessionOAuth.getEmail()+"_"+sessionOAuth.getAuthVendor();
		}
		
		// 현재스크랩 현황 반영 저장
		// 기존 스크랩 현황 삭제 후 신규현황 삽입
		List<Scrap> scrap = scrapService.getScrapListByUsername(username);
		
		if (ids.equals("") || ids == null) { // 인자 미전송시
			
			// 회원 전체 스크랩 삭제
			if (scrap.isEmpty() == false) {
				result = scrapService.deleteAllScrapsByUsername(username) == true ? false:true;
			}
			
		} else {// 인자 전송시
			
			String idArr[] = ids.split("\\,");
			List<String> list = new ArrayList<>();
			list.addAll(Arrays.asList(idArr));
			List<Integer> foodIds = list.stream().map(x->Integer.parseInt(x)).toList();
			foodIds.forEach(x->{log.info("id:"+x);});
			
			if (scrap.isEmpty() == false) {
				result = scrapService.deleteAllScrapsByUsername(username) == true ? false:true;
			}
			
			for (int foodId : foodIds) {
				result = scrapService.saveScrap(username, foodId);
			}
		}//if
    	
        return new ResponseEntity<>(result,HttpStatus.OK);
    }
    
    
}
    


