package com.dementia.memoryTable.domain;

import java.util.List;

import org.jsoup.select.Elements;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="DEMENTIA_DIET_TBL")
@SequenceGenerator(
	    name = "DEMENTIA_SEQ_GENERATOR",
	    sequenceName = "DEMENTIA_SEQ",
	    initialValue = 1,
	    allocationSize = 1)
// JPA형식
public class DietVO {
	// AnyEdit

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.SEQUENCE,
	   generator = "DEMENTIA_SEQ_GENERATOR") // 오타 교정
	private int id;

	@Column(name = "DIET_NAME")
	private String dietName;

	@Column(name = "FOOD_NAME")
	private String foodName;

	@Column(name = "MINOR_INGREDIENT")
	private String minorIngredient;

	// 이미지 파일 형식
	// uuid_메인_번호.jpg
	// ex) 0a6847840e0a95bbf6ea5818f3bdff391_medi_1.jpg
	@Column(name="FOOD_IMG")
	private String foodImg;


	@Column(name= "DIET_TYPE")
	private String dietType;

	@Column
	private String recipe;

	@Column
	private String ingredient;
	//private List<String> ingredients; // ingredients 필드 추가

	@Column(name = "HEALTH_BENEFITS")
	private String healthBenefits;

	@Column(name = "ORIGINAL_ID")
	private String originalId;
	// minorIngredient, healthBenefits 부분지우기
	 // 이 필드에 대한 getter/setter는 자동 생성됩니다.




}
