package com.dementia.memoryTable.controller;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dementia.memoryTable.domain.DietVO;
import com.dementia.memoryTable.domain.Ingredient;
import com.dementia.memoryTable.domain.IngredientBox;
import com.dementia.memoryTable.domain.PageVO2;
import com.dementia.memoryTable.service.DietService;

import jakarta.servlet.ServletContext;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("diet")
@Slf4j
public class DietListController {

	@Autowired
	DietService dietService;

//	@Autowired
//	ServletContext application;

	@Value("${image.repo.location}")
	String filePath;

	// String 처리
	@GetMapping("list")
	public String list(@RequestParam(value="page", defaultValue="1") int page,
			   @RequestParam(value="limit", defaultValue="12") int limit,
			   Model model) {

		log.info("식단레시피 목록");
		List<DietVO> list = dietService.getDietList(page, limit);

		// 총 레시피 개수
		int listCount = dietService.getAllCount();

		// 총 페이지 수
		int maxPage = PageVO2.getMaxPage(listCount, limit);
		// 현재 페이지에 보여줄 시작 페이지 수 (1, 11, 21,...)

		// 현재 페이지 -> 페이지 전개 -> startPage
		//	1 -> 1,2,3 -> 1 제외후 +1씩 증가
		//	2 -> 1,2,3 -> 1
		//	3 -> 2,3,4 -> 2
		//	4 -> 3,4,5 -> 3
		//	5 -> 4,5,6 -> 4
		//	6 -> 5,6,7 -> 5
		int startPage = PageVO2.getStartPage(page, 3, limit);
		// 현재 페이지에 보여줄 마지막 페이지 수(10, 20, 30, ...)
   	    // int endPage = startPage + 10;
		int endPage = PageVO2.getEndPage(page, maxPage, 3);

//   	    if (endPage > maxPage) endPage = maxPage;

	    PageVO2 pageVO2 = new PageVO2();
		pageVO2.setEndPage(endPage);
		pageVO2.setListCount(listCount);
		pageVO2.setMaxPage(maxPage);
		pageVO2.setCurrPage(page);
		pageVO2.setStartPage(startPage);

		pageVO2.setPrePage(pageVO2.getCurrPage()-1 < 1 ? 1 : pageVO2.getCurrPage()-1);
		pageVO2.setNextPage(pageVO2.getCurrPage()+1 > pageVO2.getEndPage() ? pageVO2.getEndPage() : pageVO2.getCurrPage()+1);

		model.addAttribute("pageVO2", pageVO2);
		model.addAttribute("dietCardList", list);

		log.info("page 정보 : " + pageVO2);

		  // 로그 출력 추가
	    log.info("Diet List: " + list);
	    log.info("Page Info: " + pageVO2);

		//  페이지 리턴
		return "dietCardList";
		// dietList에 연동 안됨
	}
	// 상세 페이지
	@GetMapping("detail/{id}")
	//public String detail(@PathVariable("id") String id, Model model)
	public String detail(@PathVariable("id") int id, Model model)

	{
		log.info("레시피 상세 페이지 id: " + id);
		DietVO diet = dietService.getDietById(id);
		// model.addAttribute("diet",diet);

		// 재료 데이터 처리
		String ingredients = diet.getIngredient();
		log.info("재료 : " +ingredients);
		if (ingredients == null || ingredients.isEmpty()) {
		    ingredients = "No ingredients available.";
		}
		// 클래스 이름을 통해 정적 메서드 호출
		String formattedIngredients = Ingredient.formatIngredients(ingredients);

		// 조리순서 가져오기
		// 이미지 URL 경로 -> 상대 경로로 변경하기 application원형
		//String path = application.getContextPath() + "/diet/detail/";
		// String path = application.getContextPath() + "/recipeImg/";

	    // 조리순서 가져오기
	    // 이미지 URL 경로 (수정)
	   // String path = "/recipeImg/thumb/"; // 상대 경로 사용

		String recipeImg = diet.getFoodImg(); // 메인 이미지의 파일 이름 (ID)
		// 조리법 줄바꿈 계산
		// 정규 표현식:
		// \\r?\\n|\\r : 개행 문자(\r, \n, \r\n)
		// \\s+ : 하나 이상의 공백 문자
		// \\. : 점(.)
	 	// String[] steps = diet.getRecipe().split("(?<!\\d)\\.\\s*|\\r?\\n|\\r");
		String[] steps = diet.getRecipe().split("\\*");
	 	List<String> stepList = Arrays.asList(steps);

	 	// 초기화 상태 레시피 이미지
		String[] stepImages = new String[steps.length];
		String imgFile[] = recipeImg.split("\\.");

 		for(int i =0; i<stepImages.length; i++) {
 			// 파일명 + 확장자
			//stepImages[i] = imgFile[0] + "_" + (i+1) + "." + imgFile[1];
 			stepImages[i] = imgFile[0] + "_" + (i+1) + ".jpg";
			// 3d0336418813d83c71eadcc47cd1b47b1.jpg_1.jpg

 			// 레시피 이미지 파일 유효성 점검(파일존재여부 점검) -> 파일 부재시 "없음" or "null" 표시
 			if (Files.isReadable(Paths.get(filePath + stepImages[i])) == false) {
 				stepImages[i] = "없음";
 			}
		}

		log.info("Step Images: " + Arrays.toString(stepImages));

		// 모델 추가
		// 포맷된 재료 데이터를 모델에 추가
	    model.addAttribute("formattedIngredients",formattedIngredients);
		model.addAttribute("steps", steps);
		model.addAttribute("stepList", stepList);
		model.addAttribute("stepImages", stepImages);
		model.addAttribute("diet", diet);

		return "dietDetail";
	}

	@GetMapping("/popular")
	public List<DietVO> getTop4PopularDiets(Pageable pageable){
		return dietService.getTop4PopularDiets();
	}
	@GetMapping("/newest")
	public List<DietVO> getTop8NewsDiets(Pageable pageable){
		return dietService.getTop8NewsDiets();

	}

	 // 검색 결과를 처리하는 메서드
    @GetMapping("/diet/search")
    public String searchRecipes(@RequestParam("query") String query, Model model) {
        // 검색어를 기반으로 레시피를 검색합니다.
        List<DietVO> recipes = dietService.searchByQuery(query); // 검색 로직 구현 필요
        model.addAttribute("dietCardList", recipes);
        return "recipePage"; // 결과를 보여줄 뷰 이름 (레시피 페이지)
    }

	@ControllerAdvice
	public class GlobalExceptionHandler {
	    @ExceptionHandler(IllegalArgumentException.class)
	    public String handleIllegalArgumentException(IllegalArgumentException e, Model model) {
	        model.addAttribute("errorMessage", e.getMessage());
	        return "error"; // error.html 페이지로 이동
	    }
	}
}