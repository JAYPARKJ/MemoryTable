package com.dementia.memoryTable.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dementia.memoryTable.domain.Scrap;

@Repository
public interface ScrapRepository extends JpaRepository<Scrap, Long> {

	List<Scrap> findByUsername(String username);

    Optional<Scrap> findByUsernameAndFoodId(String username,int foodId);

    List<Scrap> findByFoodId(int foodId);

    int deleteByUsernameAndFoodId(String username,int foodId);

    int deleteByUsername(String username);
}