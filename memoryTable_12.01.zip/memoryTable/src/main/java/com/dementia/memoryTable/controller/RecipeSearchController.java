package com.dementia.memoryTable.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dementia.memoryTable.domain.PageVO2;
import com.dementia.memoryTable.service.RecipeService;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/diet")
@Slf4j
public class RecipeSearchController {

	@Autowired
	RecipeService recipeService;

	@GetMapping("/searchAllRecipes")
	public String searchAllRecipes(@RequestParam(value = "currPage", defaultValue = "1", required = true) int page,
									@RequestParam(value = "limit", defaultValue = "12") int limit,
									@RequestParam(value = "searchKey") String searchKey,
									@RequestParam(value = "searchWord") String searchWord,
									Model model) {

		log.info("레시피 검색(search) : ");
		List<Map<String, Object>> recipes = new ArrayList<>();

		// 검색어 공백 제거
		searchWord = searchWord.trim();

		log.info("검색어 : {}", searchWord);

		recipes = recipeService.selectRecipeBySearchingAndPaging(searchKey, searchWord, page, limit, "DESC");

		// 총 "검색" 레시피 수
		int listCount = recipeService.selectCountBySearching(searchKey, searchWord);

		// 총 페이지 수
		int maxPage = PageVO2.getMaxPage(listCount, limit);
		// 현재 체이지에 보여줄 시작 페이지 수 (1, 11, 21, ...)
		int startPage = PageVO2.getStartPage(page, 3, limit);
		// 현재 페이지에 보여줄 마지막 페이지 수 (10, 20, 30, ...)
		int endPage = PageVO2.getEndPage(page, maxPage, 3);

		PageVO2 pageVO2 = new PageVO2();
		pageVO2.setEndPage(endPage);
		pageVO2.setListCount(listCount);
		pageVO2.setMaxPage(maxPage);
		pageVO2.setCurrPage(page);
		pageVO2.setStartPage(startPage);

		pageVO2.setPrePage(pageVO2.getCurrPage() - 1 < 1 ? 1 : pageVO2.getCurrPage() - 1);
		pageVO2.setNextPage(pageVO2.getCurrPage() + 1 > pageVO2.getEndPage() ? pageVO2.getEndPage() : pageVO2.getCurrPage() + 1);

		model.addAttribute("pageVO2", pageVO2);
		model.addAttribute("recipes", recipes);

		model.addAttribute("searchKey", searchKey);
		model.addAttribute("searchWord", searchWord);

		recipes.forEach(x -> x.entrySet().forEach(k -> { log.info("searchRecipe : " + k );} ));

		return "/dietCardList";

	}

	// 11.01 gnb 검색 기능 추가
	@GetMapping("/gnbsearchAllRecipes")
	public String searchAllRecipes(@RequestParam(value = "currPage", defaultValue = "1", required = true) int page,
									@RequestParam(value = "limit", defaultValue = "12") int limit,
									@RequestParam(value = "searchWords") String searchWords,
									Model model) {

		log.info("레시피 검색(search) : ");
		List<Map<String, Object>> recipes = new ArrayList<>();

		// 검색어 공백 제거
		searchWords = searchWords.trim();

		log.info("검색어 : {}", searchWords);

		recipes = recipeService.gnbRecipeBySearchingAndPaging(searchWords, page, limit, "DESC");

		// 총 "검색" 레시피 수
		int listCount = recipeService.gnbCountBySearching(searchWords);

		// 총 페이지 수
		int maxPage = PageVO2.getMaxPage(listCount, limit);
		// 현재 체이지에 보여줄 시작 페이지 수 (1, 11, 21, ...)
		int startPage = PageVO2.getStartPage(page, 3, limit);
		// 현재 페이지에 보여줄 마지막 페이지 수 (10, 20, 30, ...)
		int endPage = PageVO2.getEndPage(page, maxPage, 3);

		PageVO2 pageVO2 = new PageVO2();
		pageVO2.setEndPage(endPage);
		pageVO2.setListCount(listCount);
		pageVO2.setMaxPage(maxPage);
		pageVO2.setCurrPage(page);
		pageVO2.setStartPage(startPage);

		pageVO2.setPrePage(pageVO2.getCurrPage() - 1 < 1 ? 1 : pageVO2.getCurrPage() - 1);
		pageVO2.setNextPage(pageVO2.getCurrPage() + 1 > pageVO2.getEndPage() ? pageVO2.getEndPage() : pageVO2.getCurrPage() + 1);

		model.addAttribute("pageVO2", pageVO2);
		model.addAttribute("recipes", recipes);

		model.addAttribute("searchWord", searchWords);

		recipes.forEach(x -> x.entrySet().forEach(k -> { log.info("searchRecipe : " + k );} ));

		return "/dietCardList";

	}

}
