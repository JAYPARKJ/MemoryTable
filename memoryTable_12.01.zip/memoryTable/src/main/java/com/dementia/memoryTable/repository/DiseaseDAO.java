package com.dementia.memoryTable.repository;

import org.springframework.data.repository.CrudRepository;

import com.dementia.memoryTable.domain.DiseaseVO;

public interface DiseaseDAO extends CrudRepository<DiseaseVO, String> {

}
