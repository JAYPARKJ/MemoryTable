package com.dementia.memoryTable.service;

import java.util.List;

import com.dementia.memoryTable.domain.UploadFile;

public interface FileService {

	List<UploadFile> findAll();

	void deleteAllById(List<Integer> deleteImageIdList);

	void deleteById(int boardNum);

}
