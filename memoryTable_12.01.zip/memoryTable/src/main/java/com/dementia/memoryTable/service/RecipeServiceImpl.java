package com.dementia.memoryTable.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import com.dementia.memoryTable.repository.RecipeDAO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RecipeServiceImpl implements RecipeService {

	@Autowired
	RecipeDAO recipeDAO;

	@Transactional(readOnly = true)
	@Override
	public List<Map<String, Object>> selectRecipeBySearchingAndPaging(String searchKey, String searchWord, int page,
			int limit, String ordering) {
		return recipeDAO.selectRecipeBySearchingAndPaging(searchKey, searchWord, page, limit, ordering);
	}

	@Transactional(readOnly = true)
	@Override
	public int selectCountBySearching(String searchKey, String searchWord) {
		return recipeDAO.selectCountBySearching(searchKey, searchWord);
	}

	// 11.01 gnb 검색 기능 추가
	@Transactional(readOnly = true)
	@Override
	public List<Map<String, Object>> gnbRecipeBySearchingAndPaging(String searchWord, int page, int limit,
			String ordering) {
		return recipeDAO.gnbRecipeBySearchingAndPaging(searchWord, page, limit, ordering);
	}

	// 11.01 gnb 검색 기능 추가
	@Transactional(readOnly = true)
	@Override
	public int gnbCountBySearching(String searchWord) {
		return recipeDAO.gnbCountBySearching(searchWord);
	}

}
