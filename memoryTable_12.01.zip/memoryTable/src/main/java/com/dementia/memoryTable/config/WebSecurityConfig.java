package com.dementia.memoryTable.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
/**
 * @author javateam
 *
 */
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.config.Customizer;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.config.annotation.web.configurers.PasswordManagementConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.RememberMeServices;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;
import org.springframework.security.web.authentication.rememberme.TokenBasedRememberMeServices;
import org.springframework.security.web.authentication.rememberme.TokenBasedRememberMeServices.RememberMeTokenAlgorithm;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;

import com.dementia.memoryTable.service.CustomOAuth2UserService;
import com.dementia.memoryTable.service.CustomProvider;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

// spring & thymeleaf :
// https://www.thymeleaf.org/doc/articles/springsecurity.html

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
@Slf4j
public class WebSecurityConfig {

	@Autowired
	CustomProvider customProvider;

	private final CustomOAuth2UserService customOAuth2UserService;

	// private final UserDetailsService userDetailsService;

	private final DataSource dataSource;

	@Bean
	public BCryptPasswordEncoder bCryptPasswordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public SecurityFilterChain filterChainNaverAndGoogle(HttpSecurity http) throws Exception {

		log.info("naver & google 로그인 필터");

		http.csrf(csrfCustomizer -> csrfCustomizer.disable());

		http.headers(headersCustomizer -> headersCustomizer
						.frameOptions(Customizer.withDefaults()).disable());

		/////////////////////////////////////////////////////////////////////////////////////////////

//		http.userDetailsService(userDetailsService);
//
//		http.authenticationProvider(customProvider);

		/////////////////////////////////////////////////////////////////////////////////////////////

		http.authorizeHttpRequests(authorizeHttpRequestsCustomizer -> authorizeHttpRequestsCustomizer
				// 해당 url을 허용한다.
				.requestMatchers("/resources/**", "/loginError", "/home", "/",
								"/login/idCheck", "/loginForm","/member/hasFld/**",
								"/join_user", "/join_admin", "/member/joinUser", "/member/joinAdmin", "/member/join", "/AdminOrUser",
								"/board/list", "/board/view/**", "/board/getRepliesAllNoPw", "/board/image/**",
								"/mailSend/**", "/checkRandomNum/**", "/sendPw/**",
								"/oauth2/authorization/**",
								"/find/result", "/findId", "/foundId", "/findPw",
								"/diet/detail/**", "/diet/list", "/diet/detail/**","/diet/search/", "/scrapList",
								"/diet/searchAllRecipes", "/diet/gnbsearchAllRecipes",
								"/error") // 11.15 로그인 에러 페이지 추가
				.permitAll()
				// admin 폴더에 경우 admin(ROLE_ADMIN) 롤이 있는 사용자에게만 허용
				// .antMatchers("/admin/**").hasAnyRole("ROLE_ADMIN")
				.requestMatchers("/admin/**").hasAnyAuthority("ROLE_ADMIN")
				// user 폴더에 경우 user(ROLE_USER) 롤이 있는 사용자에게만 허용
				.requestMatchers("/secured/**", "/member/view",
								 "/member/hasFldForUpdate/**", "/member/update",
								 "/member/updateProc", "/recomm/recipe",
								 "/scrapList", "/scrapListOAuth", "/registFoodId/**", "/registFoodIds") // 11.14 추가
				.hasAnyAuthority("ROLE_USER")

				// 공용 권한 (관리자, 회원, 비회원)
				// .requestMatchers("/board/view/**")
				// .hasAnyAuthority("ROLE_ADMIN", "ROLE_USER", "ROLE_ANONYMOUS")

				//
                // 게시판 관련 링크 추가
                .requestMatchers("/board/write","/board/writeProc",
                				 "/board/image", "/board/image/**",
	                			 "/board/searchList",
	                			 "/board/update", "/board/updateProc",
	                			 "/board/replyWrite", "/board/replyUpdate",
	                			 "/board/getRepliesAll", "/board/replyDelete",
	                			 "/board/deleteProc").authenticated()
				.anyRequest().authenticated());

		http.logout(logoutCustomizer -> logoutCustomizer.logoutSuccessUrl("/"));

		// OAuth 로그인
		http.oauth2Login(oauth2LoginCustomizer -> oauth2LoginCustomizer
							.loginPage("/loginForm") // 10.24일 추가
							.defaultSuccessUrl("/home") // 변경 : OAuth 적용으로 인한 변경
							.failureUrl("/loginForm") // 10.24일 추가
							.userInfoEndpoint(userInfoEndpointCustomizer -> userInfoEndpointCustomizer
									 				.userService(customOAuth2UserService)));

		// 자체 로그인
		http.formLogin(formLogin -> formLogin
						// login ==> loginForm 변경 : OAuth와의 충돌 방지
						.loginProcessingUrl("/loginForm")
						.loginPage("/loginForm")
							.usernameParameter("username")
							.passwordParameter("password")
							.defaultSuccessUrl("/home")
						.failureUrl("/loginError")
						.permitAll())
			// logout 핸들링 처리
			.logout((logout) -> logout
						.logoutSuccessUrl("/loginForm")
						.permitAll()
					);

		// 예외 처시 해당 url로 이동
		http.exceptionHandling(handler -> handler.accessDeniedPage("/403"));

		return http.build();

	}

	// remember-me 관련 정보 DB 저장
	private PersistentTokenRepository getJDBCRepository() {

		JdbcTokenRepositoryImpl repo = new JdbcTokenRepositoryImpl();
		repo.setDataSource(dataSource);

		return repo;
	} //

	// token 기반 remember-me 서비스
	@Bean
	RememberMeServices rememberMeServices(UserDetailsService userDetailsService) {

		RememberMeTokenAlgorithm encodingAlgorithm = RememberMeTokenAlgorithm.SHA256;
		TokenBasedRememberMeServices rememberMe = new TokenBasedRememberMeServices("javateam", userDetailsService,
				encodingAlgorithm);
		rememberMe.setMatchingAlgorithm(RememberMeTokenAlgorithm.MD5);

		return rememberMe;
	}

	// security URL 열외(제외) : ex) permitAll 유사한 개념
	@Bean
	public WebSecurityCustomizer webSecurityCustomizer() {

		return (web) -> web.ignoring()
						.requestMatchers("/bootstrap/**",
										 "/css/**",
										 "/js/**",
										 "/axios/**",
										 "/bootstrap-icons/**",
										 "/summernote/**",
										 "/jquery/**",
										 "/image/**",
										 "/webjars/**",
										 "/recipeImg/**");
	}

}