package com.dementia.memoryTable.repository;

import org.springframework.data.repository.CrudRepository;

import com.dementia.memoryTable.domain.HealthVO;

public interface HealthDAO extends CrudRepository<HealthVO, String> {

}