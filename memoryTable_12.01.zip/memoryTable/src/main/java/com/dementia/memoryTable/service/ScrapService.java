package com.dementia.memoryTable.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import com.dementia.memoryTable.domain.Scrap;
import com.dementia.memoryTable.repository.ScrapRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ScrapService {

    // ScrapRepository를 주입받기 위한 필드
    private ScrapRepository scrapRepository;

    @Autowired
	PlatformTransactionManager dsTxManager;

    TransactionTemplate txTemplate;

    // 생성자를 통해 ScrapRepository를 주입
    @Autowired
    public ScrapService(ScrapRepository scrapRepository,PlatformTransactionManager txManager) {
        this.scrapRepository = scrapRepository;
		this.txTemplate = new TransactionTemplate(txManager);
    }

    /**
     * 사용자의 스크랩 정보를 저장하는 메서드
     *
     * @param username 사용자 이름
     * @param foodId 스크랩할 음식의 ID
     * @return
     */
    @Transactional
    public boolean saveScrap(String username, int foodId) {
        // 새로운 Scrap 객체 생성
        Scrap scrap = new Scrap();
        // 사용자 이름과 음식 ID 설정
        scrap.setUsername(username);
        scrap.setFoodId(foodId);
        // Scrap 객체를 데이터베이스에 저장
        scrap.setCreatedAt(new Date()); // 11.15 현재 날짜 설정 추가
        return txTemplate.execute(status -> {

				boolean result = false;

				// 회원정보 생성
				try {
						scrapRepository.save(scrap);
						result = true;

				} catch (Exception e) {
					result = false;
					log.error("ScrapService.saveScrap 에러 : " + e);
					status.setRollbackOnly();
				}
				return result;
			}
		);

    }

    /**
     * 주어진 사용자 아이디로 스크랩 리스트를 가져오는 메서드
     *
     * @param username 사용자 아이디
     * @return 사용자의 스크랩 리스트
     */
    @Transactional(readOnly = true)
    public List<Scrap> getScrapListByUsername(String username) {
        // 사용자 이름으로 스크랩 리스트를 조회하여 반환
        return scrapRepository.findByUsername(username);
    }

    /**
     * 주어진 사용자 아이디와 음식아이디로 스크랩 리스트를 가져오는 메서드
     *
     * @param username 사용자 아이디
     * @param foodId 음식 아이디
     * @return 사용자의 스크랩 리스트
     */
    @Transactional(readOnly = true)
    public Optional<Scrap> getScrapListByUsernameAndFoodId(String username, int foodId) {
        // 사용자 이름으로 스크랩 리스트를 조회하여 반환
        return scrapRepository.findByUsernameAndFoodId(username, foodId);
    }

    /**
     * 사용자의 스크랩 정보를 삭제하는 메서드
     *
     * @param username 사용자 이름
     * @param foodId 스크랩할 음식의 ID
     * @return
     */
    @Transactional
    public boolean deleteScrap(String username, int foodId) {

        return txTemplate.execute(status -> {

				boolean result = false;

				// 회원정보 생성
				try {
						result = scrapRepository.deleteByUsernameAndFoodId(username, foodId) > 0 ?  true:false;

				} catch (Exception e) {
					result = false;
					log.error("ScrapService.deleteScrap 에러 : " + e);
					status.setRollbackOnly();
				}
				return result;
			}
		);
    }

    /**
     * 사용자의 스크랩 전체정보를 삭제하는 메서드
     *
     * @param username 사용자 이름
     * @return
     */
    @Transactional
    public boolean deleteAllScrapsByUsername(String username) {

        return txTemplate.execute(status -> {

				boolean result = false;

				// 회원정보 생성
				try {
						result = scrapRepository.deleteByUsername(username)> 0 ?  true:false;

				} catch (Exception e) {
					result = false;
					log.error("ScrapService.deleteAllScrapsByUsername 에러 : " + e);
					status.setRollbackOnly();
				}
				return result;
			}
		);

    }

}
