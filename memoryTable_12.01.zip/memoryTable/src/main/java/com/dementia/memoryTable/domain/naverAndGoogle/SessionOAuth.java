package com.dementia.memoryTable.domain.naverAndGoogle;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Data;

// @Getter
@Data
public class SessionOAuth implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String name;
	private String email;
	private String mobile;
	
	// 추가
	private String authVendor;
	
	// 10.04
	private LocalDateTime createdDate;
	private LocalDateTime modifiedDate;
	
	public SessionOAuth(OAuthVO Oauth) {
		this.name = Oauth.getName();
		this.email = Oauth.getEmail();
		this.mobile = Oauth.getMobile();
		this.authVendor = Oauth.getAuthVendor();
		this.createdDate = Oauth.getCreatedDate(); // 10.04
		this.modifiedDate = Oauth.getModifiedDate(); // 10.04
	}
}
