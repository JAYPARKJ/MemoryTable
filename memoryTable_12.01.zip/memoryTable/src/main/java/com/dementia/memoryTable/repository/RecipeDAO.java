package com.dementia.memoryTable.repository;

import java.util.List;
import java.util.Map;

public interface RecipeDAO {

	/**
	 * 10.30 레시피/재료 검색
	 *
	 * @param searchKey 검색 구분 ex) FOOD_NAME(레시피 제목), INGREDIENT(재료)
	 * @param searchWord 검색어 ex) 칼국수, 달걀
	 * @param page 현재 페이지 ex) 1
	 * @param limit 페이지당 레코드 수 ex) 10
	 * @param ordering 정렬 ex) ASC(오름차순), DESC(내림차순)
	 * @return
	 */
	List<Map<String, Object>> selectRecipeBySearchingAndPaging(String searchKey, String searchWord, int page, int limit, String ordering);

	/**
	 * 10.30
	 *
	 * @param searchKey 검색 키워드(구분)
	 * @param searchWord 검색어
	 * @return 검색 된 총 레시피 수
	 */
	public int selectCountBySearching(String searchKey, String searchWord);

	/**
	 * 11.01 gnb 검색기능 추가
	 *
	 * @param searchWord 검색어 ex) 칼국수, 달걀
	 * @param page 현재 페이지 ex) 1
	 * @param limit 페이지당 레코드 수 ex) 10
	 * @param ordering 정렬 ex) ASC(오름차순), DESC(내림차순)
	 * @return
	 */
	List<Map<String, Object>> gnbRecipeBySearchingAndPaging(String searchWord, int page, int limit, String ordering);

	/**
	 * 11.01 gnb 검색기능 추가
	 *
	 * @param searchWord 검색어
	 * @return 검색 된 총 레시피 수
	 */
	public int gnbCountBySearching(String searchWord);
}
