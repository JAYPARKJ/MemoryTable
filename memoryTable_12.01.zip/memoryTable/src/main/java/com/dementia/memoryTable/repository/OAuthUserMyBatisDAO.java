package com.dementia.memoryTable.repository;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dementia.memoryTable.domain.naverAndGoogle.OAuthVO;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
@Transactional
public class OAuthUserMyBatisDAO {
	
	@Autowired
	SqlSession sqlSession; // MyBatis Session 객체
   
    public void insertOAuthVO(OAuthVO oAuthVO) {
    	
    	log.info("insertOAuthVO");
    	sqlSession.insert("mapper.OAuthUser.insertOAuthVO", oAuthVO);
    } //
    
    public OAuthVO selectOAuthVO(String email) {

	   return sqlSession.selectOne("mapper.OAuthUser.selectOAuthVO", email);
	} //
    
    public OAuthVO selectOAuthVO(String email, String authVendor) {
    	Map<String, String> map = new HashMap<>();
    	map.put("email", email);
    	map.put("authVendor", authVendor);

 	   return sqlSession.selectOne("mapper.OAuthUser.selectOAuthVOByEmailAndAuthVendor", map);
 	} //
    
    public void updateOAuthVO(OAuthVO oAuthVO) {
    	sqlSession.update("mapper.OAuthUser.updateOAuthVO", oAuthVO);
    }
    
    public void deleteOAuthVO(String email, String authVendor) {
    	Map<String, String> map = new HashMap<>();
    	map.put("email", email);
    	map.put("authVendor", authVendor);

 	   sqlSession.delete("mapper.OAuthUser.deleteOAuthVO", map);
    }
   
}
