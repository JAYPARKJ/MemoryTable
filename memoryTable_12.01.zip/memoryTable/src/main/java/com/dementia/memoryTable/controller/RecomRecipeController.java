package com.dementia.memoryTable.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.dementia.memoryTable.domain.CustomUser;
import com.dementia.memoryTable.domain.DietVO;
import com.dementia.memoryTable.domain.HealthVO;
import com.dementia.memoryTable.domain.naverAndGoogle.OAuthVO;
import com.dementia.memoryTable.domain.naverAndGoogle.SessionOAuth;
import com.dementia.memoryTable.service.DietService;
import com.dementia.memoryTable.service.HealthDiagnosticService;
import com.dementia.memoryTable.service.HealthFilterService;

import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class RecomRecipeController {

	@Autowired
	HealthDiagnosticService healthDiagnosticService;

	@Autowired
	HealthFilterService healthFilterService;

	@Autowired
	DietService dietService;

	// 자체 로그인
	@GetMapping("/recomm/recipe")
	public String recommRecipe (Model model) {

		log.info("recommend recipe :");

		String movePath = "";

		// Security pricipal 객체 (사용자 인증/인가 정보 객체)
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		CustomUser user = null;

		if (principal instanceof CustomUser) {
			user = ((CustomUser) principal);
		}

		log.info("user : " + user);

		// ID
		String id = user.getUsername();

		// 개인 건강정보 조회 11.04
		HealthVO healthVO = healthFilterService.getUserHealthInfo(id);

		// null값 여부 확인
		log.info("null값 여부: " + null);
		if (healthVO == null) {
			movePath = "redirect:/member/privateHealthInput";
		}
		else {
			// forward
			// 개인 RDA (1일 권장량), 추천레시피 전송 (String disease, char gender, int age, float height, int weight, float PA);
			int rda = healthDiagnosticService.calculateRDA(id, healthVO.getGender(), healthVO.getAge(), healthVO.getHeight(), healthVO.getWeight(), healthVO.getActivity());
			// public Map<String, Integer> getNutrientRequirements(List<String> diseases, int caloricNeeds) {
			List<String> diseases = Arrays.asList(healthVO.getDisease());
			int caloricNeeds = rda;
			Map<String, Integer> rdaDisease = healthDiagnosticService.getNutrientRequirements(diseases, rda);

			Map<String, String> nutrientMap = new HashMap<>();
			nutrientMap.put("protein", "단백질(protein)");
			nutrientMap.put("sodium", "나트륨(sodium)");
			nutrientMap.put("carbs", "탄수화물(carbs)");
			nutrientMap.put("fat", "지방(fat)");
			nutrientMap.put("omega-3", "오메가3(omega-3)");

			// String - key값 변경, key = 영양성분 (한글 병행기록 변환)
			rdaDisease.keySet().stream().map(x -> nutrientMap.get(x)).toList();

			rdaDisease.entrySet().forEach(x -> {log.info(" " + x);});

			// 추천 레시피 가져오기 (String foodKind, Collection<String> keywords, Collection<String> anotherKeywords) {
			List<DietVO> meal = dietService.recommendMeal();

			// model 인자 전송
			model.addAttribute("rda", rda);
			model.addAttribute("meal", meal);
			model.addAttribute("rdaDisease", rdaDisease);

			movePath = "/member_health/recomm_recipe";
		}

		return movePath;
	}

}
