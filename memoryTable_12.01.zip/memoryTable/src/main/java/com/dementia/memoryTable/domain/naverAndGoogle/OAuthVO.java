package com.dementia.memoryTable.domain.naverAndGoogle;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
@Builder
@SequenceGenerator (
		name = "USER_SEQ_GENERATOR",
		sequenceName = "USER_SEQ",
		initialValue = 1,
		allocationSize = 1)
@Table (name="USER_TBL")
public class OAuthVO extends BaseTimeEntity {

	@Id
	@Column(nullable=false, precision=10, scale=0) // number(10, 0)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,
					generator = "USER_SEQ_GENERATOR")

	private BigDecimal id;

	@Column(nullable = false)
	private String name;

	@Column(nullable = false)
	private String email;

	@Column(nullable = false)
	private String mobile;


	// 인증 포탈 이름: 전송용으로만 사용 : ex) naver, google
	@Column(name="auth_vendor")
	private String authVendor;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false, name="role")
	private OAuthRole role;

	@Builder // String authVendor 추가
	public OAuthVO(String name, String email, String mobile, OAuthRole role,  String authVendor) {
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.role = role;
		this.authVendor = authVendor;
	}

	public OAuthVO update(String name, String email, String authVendor) {
		this.name = name;
		this.email = email;
		this.authVendor = authVendor;

		return this;
	}

	public String getRoleKey() {
		return this.role.getKey();
	}

}
