package com.dementia.memoryTable.domain;

public class RecipeSteps {

	private String recipe;
	private String steps;

	public RecipeSteps(String recipe, String steps) {
		this.recipe = recipe;
		this.steps = steps;
	}

	public static String formatRecipe(String str) {

		String[] strs = str.split("\\.");



		return str;


	}

}
