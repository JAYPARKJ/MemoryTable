package com.jay.foodCrawlingPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodCrawlingPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
