package com.jay.foodCrawlingPractice.crawl;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class FoodRecipeCrawlTest {

	@Test
	public void test() {
		 
		// 음식 고유 번호 추출
		Document doc;
		
		// id 분리 ->  for문 확보 
		String id = "6846802";
		
		// url 주소 : https://www.10000recipe.com/recipe/6846802
		String url = "https://www.10000recipe.com/recipe/" + id;
		
		try {
			
			doc = Jsoup.connect(url).get();
			// 레시피 1페이지씩(낱개페이지)
			
			// 이미지 가져오기
			// <div class="centeredcrop"> 밑에
			//   <img id="main_thumbs" src="https://recipe1.ezmember.co.kr/cache/recipe/2016/04/21/8183a383df6cd2a74b410d44f58780361.jpg" alt="main thumb">
			
			String img = doc.select("div.centeredcrop img").attr("src");
			log.info("img : " + img); // https://recipe1.ezmember.co.kr/cache/recipe/2016/04/21/8183a383df6cd2a74b410d44f58780361.jpg
			// D:\student\JAY\foodimg
			String path ="D:/student/JAY/foodimg/"; 
			String file[] = img.split("/");
			path += file[file.length-1];
			log.info("path : " + path); // D:/student/JAY/foodimg/8183a383df6cd2a74b410d44f58780361.jpg
			
			// 파일저장
		//	InputStream in = new URL(img).openStream();
		//	Files.copy(in, Paths.get(path), StandardCopyOption.REPLACE_EXISTING);

			////////////////////////////////////////////////////////////////////////
			//  <div class="view2_summary st3">
			// 음식명 <h3>에드워드 권의 '지중해식 연어요리' </h3>
			String title = doc.select("h3").text();
			log.info("title : " + title); // 음식명: 에드워드 권의 '지중해식 연어요리' 최근 본 레시피 
			
			//  <div class="view2_summary_in" id="recipeIntro"> 
			// 레시피 설명
			String detail = doc.select("#recipeIntro").text().trim();
			log.info("detail : " + detail);
			//  detail : 얼마전, 올리브쇼에 에드워드 권 쉐프가 출연해서 집에서 손쉽게 맛있는 생선구이를 만들수 있는 레시피를 공유해주셨어요. 방송에선 고등어를 사용했는데, 저는 연어로 레시피를 따라해봤답니다. 쉐프가 전하는 팁들을 놓치지 말고 함께 해보세요~ 맛있는 생선요리를 맛 볼 수 있어요 ^^ <=== com.jay.foodCrawlingPractice.crawl.FoodRecipeCrawlTest [2024-09-19 17:15:02.017]

			////////////////////////////////////////////////////////////////////////
			// <div class="cont_ingre2">
			// ...
			//  <div class="ingre_list_name">
			// 		  <a href="javascript:viewMaterial('2156');" onclick="ga('send', 'event', '레시피본문', '재료정보버튼클릭', '연어살');"> 연어살 <span>300g</span>  </a>
			// String ingredient = doc.select(".cont_ingre2 .ingre_list_name a").get(0).text().trim();
			// log.info("ingredient : " + ingredient); // 연어살 300g 
			
			// 배열 복수성분
			Elements ingredients = doc.select(".cont_ingre2 .ingre_list_name a");
			Elements ingredientUnits = doc.select(".cont_ingre2 .ready_ingre3 .ingre_list_ea");
			//  <div class="ready_ingre3" id="divConfirmedMaterialArea">
			// 	...
			// 		<span class="ingre_list_ea">1덩어리 </span>
			
			for(int i=0; i < ingredients.size(); i++)
			{
				log.info("ingredient - "+ i + " : "+ ingredients.get(i).text().trim());
				
				String unit = ingredientUnits.get(i).text().trim();
				log.info("재료 단위 : "+ i + " : " + (unit.equals("") ? "없음" : unit));
				
			}
			
			////////////////////////////////////////////////////////////////////////
			// <div class="view_step" id="obx_recipe_step_start" data-tag="웹-조리순서시작">
			//  	    <b>조리순서</b><span>Steps</span>
			//	... 		
			// <div id="stepDiv1" class="view_step_cont media step1"><div id="stepdescr1" class="media-body">재료를 준비해주세요!</div><div id="stepimg1">
			
			// Elements = tag들, 요소 분석 정적 분석 + 동적 분석 꼭 하기
			Elements receipeSteps = doc.select(".view_step [class^='view_step_cont media step'] [id^='stepdescr']");
			log.info("조리순서 단계 갯수 : " + receipeSteps.size());	// 조리순서 단계 갯수 : 22	
			
			for(int i = 0; i < receipeSteps.size(); i++)
			{
				log.info("receipeSteps -" + (i + 1) + " = " + receipeSteps.get(i).text().trim());
				
			}
			
			
			
			
			
		}  catch (IOException e) {
			log.error("크롤링 에러");
			e.printStackTrace();
		}
		
		
	}
}
