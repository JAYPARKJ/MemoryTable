package com.jay.foodCrawlingPractice.crawl;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class CrawlTest1 {
	// 아이디 40개 확보
	@Test
	public void test() {
		
		log.info("만개의 레시피 ID확보 :");
	
		// 음식 고유 번호 추출
		Document doc;
		// url 주소 넣기 
		String foodGallerySite = "https://www.10000recipe.com/recipe/list.html?q=지중해식";
		
		try {
			
			doc = Jsoup.connect(foodGallerySite).get();
			// SELECTOR나 정규식은 . 중요
			Elements foodListInfo = doc.select(".common_sp_list_li");
			// 갤러리 음식 갯수
			int foodLen = foodListInfo.size();
			log.info("음식 갯수 : " + foodLen);
			
			// 개별 음식 ID 확보
			//.common_sp_list_li div.common_sp_thumb a[href^="/recipe"] href 속성값 따야함 -> substring, split  6846802<- 개별 음식ID
			// 하나만 들고오기
			// Element food = foodListInfo.get(0);
			
			/*
	 		<li class="common_sp_list_li">
				<div class="common_sp_thumb">
					<a href="/recipe/6846802" class="common_sp_link">			 
		 	. class 
		 	띄어쓰기 아래
		 	https://webzz.tistory.com/664?category=759977
		 	대문자 일때는 상수
		 	*/
//			String id = food.select("div.common_sp_thumb a")
//							.attr("href")
//							.substring(8); // id : 6846802
//							
//			log.info("id : " + id); // id : /recipe/6846802
			
			for(int i=0; i<foodLen; i++)
			{
				Element food = foodListInfo.get(i);
				String id = food.select("div.common_sp_thumb a")
 						.attr("href")
 						.substring(8); // id : 6846802
				log.info(i+ "번째 아이디 : " + id );
				// 6071599
				
			}
		
			
		} catch (IOException e) {
			log.error("크롤링 오류");
			e.printStackTrace();
		}		
		
	}
}
