package com.jay.foodCrawlingPractice.crawl;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class CrawlTest2 {
	// 아이디 40개 확보
	@Test
	public void test() {
		
		log.info("만개의 레시피 ID확보 :");
	
		// 음식 고유 번호 추출
		Document doc;
		 
		try {
			// 총 104p 마지막 id : 6997310
			// ex 103p 마지막 id 6976943
			// 102p 마지막 id 6873619
			for(int j=102; j<=104; j++)
			{	
				// url 주소 넣기  
				// 쿼리 ? = ?
				String foodGallerySite = "https://www.10000recipe.com/recipe/list.html?q=지중해식&order=reco&page="+j;
				// https://www.10000recipe.com/recipe/list.html?q=%EC%A7%80%EC%A4%91%ED%95%B4%EC%8B%9D&order=reco&page=104 -> j =104
				doc = Jsoup.connect(foodGallerySite).get();
				
				log.info(j + "페이지 ----------------");
				// 페이지 마다 다르게 구현
				Elements foodListInfo = doc.select(".common_sp_list_li");
				// 갤러리 음식 갯수
				int foodLen = foodListInfo.size();
				log.info("음식 갯수 : " + foodLen);
				
				// 페이지당 음식 수
				for(int i=0; i<foodLen; i++)
				{	// 임시
					// if(i==foodLen-1) {
					Element food = foodListInfo.get(i);
					String id = food.select("div.common_sp_thumb a")
	 						.attr("href")
	 						.substring(8); // id : 6846802
					log.info(i+ "번째 아이디 : " + id );
					// 39번째 id : 6997310
					//}
				}
			}// for
			
		} catch (IOException e) {
			log.error("크롤링 오류");
			e.printStackTrace();
		}		
		
	}
}
