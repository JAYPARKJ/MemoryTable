package com.jay.foodCrawlingPractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodCrawlingPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodCrawlingPracticeApplication.class, args);
	}

}
